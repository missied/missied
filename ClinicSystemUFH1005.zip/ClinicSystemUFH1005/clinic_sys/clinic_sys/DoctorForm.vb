﻿Imports System.Data.OleDb
Imports System.Data.Common
Imports System.Data.SqlClient
Imports System.Security.Cryptography.X509Certificates
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class DoctorForm

    Dim da, db As New OleDbDataAdapter
    Dim dset As New DataSet
    Dim dset1 As New DataSet
    Dim VisitTime As String = Now.ToString("d")
    Dim VisitTime2 As String = Now.ToString("f")
    Private Sub DoctorForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database_clinicDataSet21.Waiting_List' table. You can move, or remove it, as needed.
        Me.Waiting_ListTableAdapter2.Fill(Me.Database_clinicDataSet21.Waiting_List)
        'TODO: This line of code loads data into the 'Database_clinicDataSet2.Patient_MedicalHistory' table. You can move, or remove it, as needed.
        Me.Patient_MedicalHistoryTableAdapter1.Fill(Me.Database_clinicDataSet2.Patient_MedicalHistory)
        'TODO: This line of code loads data into the 'Database_clinicDataSet2.Waiting_List' table. You can move, or remove it, as needed.
        Me.Waiting_ListTableAdapter1.Fill(Me.Database_clinicDataSet2.Waiting_List)

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        Call load1()
        Call load2()
    End Sub
    Public Sub load1()

        strsql = "select * from Waiting_List where (status = 'waiting consultation') AND (visitingtime = '" & VisitTime & "')"
        da = New OleDbDataAdapter(strsql, conn)
        dset = New DataSet
        da.Fill(dset, "Waiting_List")
        DataGridView1.DataSource = dset.Tables("Waiting_List")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        TextBox3.Text = ptnName
        TextBox4.Text = ptnID
        strsql = "Select  Age From  Patient_Information" &
        "    WHERE            (PatientID = " & (CInt(TextBox4.Text)) & ")"

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        Dim cmd As New OleDbCommand(strsql, conn)
        Dim dr As OleDbDataReader = cmd.ExecuteReader()
        dr.Read()
        Dim v As Object = dr("Age")
        TextBox2.Text = v

        strsql = "select * from Patient_MedicalHistory where (PatientID = " & (ptnID) & ")"
        Dim cmd2 As New OleDbCommand(strsql, conn)
        'Dim dr2 As OleDbDataReader = cmd.ExecuteReader()
        db = New OleDbDataAdapter(strsql, conn)
        dset = New DataSet
        db.Fill(dset, "Patient_MedicalHistory")
        DataGridView2.DataSource = dset.Tables("Patient_MedicalHistory")

        strsql = "UPDATE Waiting_List" & " SET Status = 'meet doctor'" & "  WHERE (PatientID = " & (ptnID) & ")"
        Dim cmd3 As New OleDbCommand(strsql, conn)
        cmd3.ExecuteNonQuery()

        strsql = "UPDATE Waiting_List" & " SET ConsultationTime = 'VisitTime2'" & "  WHERE (PatientID = " & (ptnID) & ")"
        Dim cmd4 As New OleDbCommand(strsql, conn)
        cmd4.ExecuteNonQuery()

        Call load1()

    End Sub

    Public Sub load2()

        strsql = "select * from Patient_MedicalHistory"
        db = New OleDbDataAdapter(strsql, conn)
        dset = New DataSet
        db.Fill(dset, "Patient_MedicalHistory")
        DataGridView2.DataSource = dset.Tables("Patient_MedicalHistory")
        'strsql = "Select NamePatient From Waiting_List WHERE (Status = 'waiting consultation') Order By (queueNo) ASC"
    End Sub

    Private Sub Exitbtn_Click(sender As Object, e As EventArgs) Handles Exitbtn.Click
        Me.Close()
        LoginForm.Show()
        Try
            strsql = "UPDATE Login_table" & " SET Status = no" & "  WHERE (UserID ='" & XX & "')"
            Dim cmd As New OleDbCommand(strsql, conn)
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show("There was an error processing your request. Please try again." & vbCrLf & vbCrLf &
                            "Original Error:" & vbCrLf & vbCrLf & ex.ToString, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        LoginForm.TextBox1.Clear()
        LoginForm.TextBox2.Clear()
    End Sub

    Private Sub NewReq_Click(sender As Object, e As EventArgs) Handles NewReq.Click
        Call load1()
    End Sub

    Private Sub ConsEnd_Click(sender As Object, e As EventArgs) Handles ConsEnd.Click
        strsql = "UPDATE Waiting_List" & " SET Status = 'complete consultation', ConsultationTime = '" & VisitTime2 & "'  WHERE (PatientID = " & (ptnID) & ")"
        Dim cmd4 As New OleDbCommand(strsql, conn)
        cmd4.ExecuteNonQuery()




    End Sub

    Private Sub dataGridView1_CellMouseClick(sender As System.Object, e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        If (e.RowIndex >= 0) Then
            Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
            ptnName = row.Cells(1).Value.ToString
            ptnID = row.Cells(6).Value.ToString
        End If
    End Sub

    'Private Sub dataGridView2_CellMouseClick(sender As System.Object, e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
    '    If (e.RowIndex >= 0) Then
    '        Dim row As DataGridViewRow = DataGridView2.Rows(e.RowIndex)
    '        RichTextBox1.Text = row.Cells(4).Value.ToString & row.Cells(6).Value.ToString

    '    End If
    'End Sub
End Class


