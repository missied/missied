﻿

Namespace clinic_sys
    Friend Class Database_clinicDataSet2TableAdapters
        Friend Class Waiting_ListTableAdapter
            Inherits clinic_sys_Display.Database_clinicDataSet2TableAdapters.Waiting_ListTableAdapter
        End Class

        Friend Class Patient_MedicalHistoryTableAdapter
            Inherits clinic_sys_Display.Database_clinicDataSet2TableAdapters.Patient_MedicalHistoryTableAdapter
        End Class
    End Class
End Namespace
