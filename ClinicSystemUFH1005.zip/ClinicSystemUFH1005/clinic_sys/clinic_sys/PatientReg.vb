﻿Imports System.Data.Common
Imports System.Data.OleDb
Imports System.DirectoryServices.ActiveDirectory
Imports System.Reflection
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class PatientReg

    Private Sub PatientReg_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        PtnIDTxt.Text = ""

        If PtnIDTxt.Text = Nothing Then
            PatientName.Text = ""
            DOBtxt.Text = ""
            Agetxt.Text = ""
            Address1txt.Text = ""
            Postcodetxt.Text = ""
            Citytxt.Text = ""
            phonePtnTxt.Text = ""
            IcNoTxt.Text = ""
            EmpIDtxt.Text = ""
            EmpAddTxt.Text = ""
            InsTypetxt.Text = ""
            BloodTxt.Text = ""
            WeightTxt.Text = ""
            HeightTxt.Text = ""
            RelNameTxt.Text = ""
            phoneRelTxt.Text = ""
            UpdBtn.Visible = False
        Else
            UpdBtn.Visible = True
        End If
    End Sub

    Private Sub UpdBtn_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub SaveBtn_Click(sender As Object, e As EventArgs) Handles SaveBtn.Click

        Dim newID As Integer
        Dim count As Int16
        Dim dateToday As String = Now.ToString("d")

        ptnName = PatientName.Text
        dobDate = DOBtxt.Text
        Age = CInt(Agetxt.Text) 'as integer
        address = Address1txt.Text
        Pcode = CInt(Postcodetxt.Text) 'as integer
        city = Citytxt.Text
        ptnPhone = CInt(phonePtnTxt.Text) 'as integer
        ICNo = IcNoTxt.Text
        EmpIDx = EmpIDtxt.Text
        If EmpIDx = "" Then
            EmpIDx = "''"
        End If
        Empx = EmpAddTxt.Text
        If Empx = "" Then
            Empx = "''"
        End If
        Ins = InsTypetxt.Text
        If Ins = "" Then
            Ins = "''"
        End If
        blood = BloodTxt.Text
        Wght = CInt(WeightTxt.Text) 'as integer
        Hght = CInt(HeightTxt.Text) 'as integer
        relName = RelNameTxt.Text
        relPhone = CInt(phoneRelTxt.Text) 'as integer

        Dim ICstr As String = CStr(ICNo)
        Dim PtnIDstr As String = CStr(ICNo).Substring(CStr(ICNo).Length - 6)
        ptnID = CInt(PtnIDstr) 'as integer

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        strsql = "select COUNT(ID) As num_patient From Patient_Information"
        Dim cmd As New OleDbCommand(strsql, conn)
        count = Convert.ToInt32(cmd.ExecuteScalar())
        newID = count + 1

        Try
            '    strsql = "INSERT INTO    Patient_Information" &
            '    " (ID, NamePatient, DOB, Age, Address, City, Postcode, PhoneNo, ICNo," &
            '" Gender, MaritalStatus, WorkStatus, EmpID, Employer, Insurance, " &
            '"BloodType, Weight, Height, RelativeName, RelativePhone, Payment, RegDate, LastUpdate, PatientID)" &
            '"VALUES (@ID, @NamePatient, @DOB, @Age, @Address, @City, @Postcode, @PhoneNo, @ICNo, @Gender, " &
            '"@MaritalStatus, @WorkStatus, @EmpID, @Employer, @Insurance, @BloodType, @Weight, @Height, @RelativeName, " &
            '"@RelativePhone, @Payment, @RegDate, @LastUpdate, @PatientID) "

            strsql = "INSERT INTO    Patient_Information" &
            "(ID, NamePatient, DOB, Age, address, city, Postcode, PhoneNo, ICNo, Gender, MaritalStatus, WorkStatus, EmpID, Employer, Insurance, BloodType, Weight, Height, RelativeName, RelativePhone, Payment, RegDate, LastUpdate, PatientID)" &
            " VALUES " &
            "(@ID, @NamePatient, @DOB, @Age, @address, @city, @Postcode, @PhoneNo, @ICNo, @Gender, @MaritalStatus, @WorkStatus, @EmpID, @Employer, @Insurance, @BloodType, @Weight, @Height, @RelativeName, @RelativePhone, @Payment, @RegDate, @LastUpdate, @PatientID)"


            'strsql = "INSERT INTO    Patient_Information" &
            '         "(ID, NamePatient, DOB, Age, address, Postcode, PhoneNo, ICNo, Gender, MaritalStatus, WorkStatus, EmpID, Employer, Insurance, BloodType, Weight, Height, Payment, RegDate, LastUpdate, PatientID, city) " &
            '"VALUES (6, 'kartini', ' 16 / 04 / 1984', 40, 'Klang', 41200, 0162497911, '840816164460', 'Female', 'Married', False, '', '', '', 'A-', 68, 158, 'Insurance', 12 / 12 / 2023, 12 / 12 / 2023, 164460, 'klang')"

            Dim cmd2 As New OleDbCommand(strsql, conn)
            cmd2.Parameters.AddWithValue("@ID", newID)
            cmd2.Parameters.AddWithValue("@NamePatient", ptnName)
            cmd2.Parameters.AddWithValue("@DOB", dobDate)
            cmd2.Parameters.AddWithValue("@Age", Age)
            cmd2.Parameters.AddWithValue("@Address", address)
            cmd2.Parameters.AddWithValue("@City", city)
            cmd2.Parameters.AddWithValue("@Postcode", Pcode)
            cmd2.Parameters.AddWithValue("@PhoneNo", ptnPhone)
            cmd2.Parameters.AddWithValue("@ICNo", ICNo)
            cmd2.Parameters.AddWithValue("@Gender", Gender)
            cmd2.Parameters.AddWithValue("@MaritalStatus", M_status)
            cmd2.Parameters.AddWithValue("@WorkStatus", Work)
            cmd2.Parameters.AddWithValue("@EmpID", EmpIDx)      'not required
            cmd2.Parameters.AddWithValue("@Employer", Empx)     'not required
            cmd2.Parameters.AddWithValue("@Insurance", Ins)     'not required
            cmd2.Parameters.AddWithValue("@BloodType", blood)   'not required
            cmd2.Parameters.AddWithValue("@Weight", Wght)       'not required
            cmd2.Parameters.AddWithValue("@Height", Hght)       'not required
            cmd2.Parameters.AddWithValue("@RelativeName", relName)      'not required
            cmd2.Parameters.AddWithValue("@RelativePhone", relPhone)    'not required
            cmd2.Parameters.AddWithValue("@Payment", pay)
            cmd2.Parameters.AddWithValue("@RegDate", dateToday)
            cmd2.Parameters.AddWithValue("@LastUpdate", dateToday)
            cmd2.Parameters.AddWithValue("@PatientID", ptnID)

            If conn.State = ConnectionState.Closed Then
                conn.Open()
            End If

            cmd2.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show("There was an error processing your request. Please try again." & vbCrLf & vbCrLf &
                        "Original Error:" & vbCrLf & vbCrLf & ex.ToString, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        msgLbl.Text = "Success Registered new patient..."


    End Sub

    Private Sub exittBtn_Click(sender As Object, e As EventArgs) Handles exittBtn.Click
        Me.Close()
        NurseForm.Show()
    End Sub
    Private Sub MaleChkBox_CheckedChanged(sender As Object, e As EventArgs) Handles MaleChkBox.CheckedChanged
        Gender = "Male"
    End Sub

    Private Sub FemaleChkBox_CheckedChanged(sender As Object, e As EventArgs) Handles FemaleChkBox.CheckedChanged
        Gender = "Female"
    End Sub

    Private Sub Yes_CheckedChanged(sender As Object, e As EventArgs) Handles Yes.CheckedChanged
        Work = True
    End Sub

    Private Sub No_CheckedChanged(sender As Object, e As EventArgs) Handles No.CheckedChanged
        Work = False
    End Sub

    Private Sub Anemia_CheckedChanged(sender As Object, e As EventArgs) Handles Anemia.CheckedChanged
        ill(0) = "Anemia"
    End Sub

    Private Sub Allergies_CheckedChanged(sender As Object, e As EventArgs) Handles Allergies.CheckedChanged
        ill(1) = "Allergies"
    End Sub

    Private Sub Asthma_CheckedChanged(sender As Object, e As EventArgs) Handles Asthma.CheckedChanged
        ill(2) = "Asthma"
    End Sub

    Private Sub Arthitis_CheckedChanged(sender As Object, e As EventArgs) Handles Arthitis.CheckedChanged
        ill(3) = "Arthitis"
    End Sub

    Private Sub Anxiety_CheckedChanged(sender As Object, e As EventArgs) Handles Anxiety.CheckedChanged
        ill(3) = "Anxiety/Depression"
    End Sub

    Private Sub Adhd_CheckedChanged(sender As Object, e As EventArgs) Handles Adhd.CheckedChanged
        ill(5) = "ADD/ADHD"
    End Sub

    Private Sub BloodClot_CheckedChanged(sender As Object, e As EventArgs) Handles BloodClot.CheckedChanged
        ill(6) = "Bloodclot"
    End Sub

    Private Sub Cancer_CheckedChanged(sender As Object, e As EventArgs) Handles Cancer.CheckedChanged
        ill(7) = "Cancer"
    End Sub

    Private Sub DiaType1_CheckedChanged(sender As Object, e As EventArgs) Handles DiaType1.CheckedChanged
        ill(8) = "Diabetes Type 1"
    End Sub

    Private Sub DiaType2_CheckedChanged(sender As Object, e As EventArgs) Handles DiaType2.CheckedChanged
        ill(9) = "Diabetes Type 2"
    End Sub

    Private Sub HiBP_CheckedChanged(sender As Object, e As EventArgs) Handles HiBP.CheckedChanged
        ill(10) = "High Blood Pressure"
    End Sub

    Private Sub HiCholes_CheckedChanged(sender As Object, e As EventArgs) Handles HiChole.CheckedChanged
        ill(11) = "High Cholesterol"
    End Sub

    Private Sub HeartAttc_CheckedChanged(sender As Object, e As EventArgs) Handles HeartAttc.CheckedChanged
        ill(12) = "High Cholesterol"
    End Sub

    Private Sub KidneyDis_CheckedChanged(sender As Object, e As EventArgs) Handles KidneyDis.CheckedChanged
        ill(13) = "Kidney Disease"
    End Sub

    Private Sub CashRB_CheckedChanged(sender As Object, e As EventArgs) Handles CashRB.CheckedChanged
        pay = "Cash"
    End Sub

    Private Sub InsRB_CheckedChanged(sender As Object, e As EventArgs) Handles InsRB.CheckedChanged
        pay = "Insurance"
    End Sub

    Private Sub SngChkBox_CheckedChanged(sender As Object, e As EventArgs) Handles SngChkBox.CheckedChanged
        M_status = "Single"
    End Sub

    Private Sub rrChkBox_CheckedChanged(sender As Object, e As EventArgs) Handles MrrChkBox.CheckedChanged
        M_status = "Married"
    End Sub

    Private Sub UpdBtn_Click_1(sender As Object, e As EventArgs) Handles UpdBtn.Click

    End Sub
End Class