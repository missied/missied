﻿Namespace clinic_sys
    Friend Class Database_clinicDataSetTableAdapters2
    End Class
End Namespace
