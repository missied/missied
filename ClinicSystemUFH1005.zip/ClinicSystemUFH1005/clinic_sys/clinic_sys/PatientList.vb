﻿Imports System.Data.OleDb
Imports System.Data.Common
Imports System.Data.SqlClient
Imports System.Security.Cryptography.X509Certificates
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class PatientList

    Dim da, db As New OleDbDataAdapter
    Dim dset As New DataSet
    Dim dset1 As New DataSet
    Dim VisitTime As String = Now.ToString("d")
    Dim VisitTime2 As String = Now.ToString("f")
    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub PatientList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database_clinicDataSet2.Patient_Information' table. You can move, or remove it, as needed.
        Me.Patient_InformationTableAdapter.Fill(Me.Database_clinicDataSet2.Patient_Information)

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        Call Load()
    End Sub
    Public Sub Load()

        strsql = "select * from Patient_Information"
        da = New OleDbDataAdapter(strsql, conn)
        dset = New DataSet
        da.Fill(dset, "Patient_Information")
        DataGridView1.DataSource = dset.Tables("Patient_Information")
    End Sub
End Class