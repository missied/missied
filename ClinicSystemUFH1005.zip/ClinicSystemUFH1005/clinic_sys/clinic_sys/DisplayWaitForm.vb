﻿Imports System.Data.OleDb
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar

Public Class DisplayWaitForm


    Dim da As New OleDbDataAdapter
    Dim dset As New DataSet

    Private Sub DisplayWaitForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim count As Integer
        Dim countwait As Integer
        Dim Todaynow As String = Now.ToString("d")
        Dim VisitTime As String = Now.ToString("d")
        Dim queueNo As Integer

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        Me.Waiting_ListTableAdapter.Fill(Me.Database_clinicDataSet2.Waiting_List)
        da = New OleDbDataAdapter("Select * from Waiting_List ", conn)
        dset = New DataSet
        da.Fill(dset, "Waiting_List")
        DataGridView1.DataSource = dset.Tables("Waiting_List").DefaultView

        strsql = "SELECT COUNT(*) FROM  Waiting_List WHERE (VisitingTime = '" & VisitTime & "')"

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If
        Dim cmd As New OleDbCommand(strsql, conn)
        count = Convert.ToInt32(cmd.ExecuteScalar())
        TextBox4.Text = count

        conn.Close()

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        strsql = "SELECT COUNT(*) AS Expr1 FROM  Waiting_List WHERE (VisitingTime = '" & VisitTime & "')" &
                " and (Status = 'meet doctor')"
        Dim cmd1 As New OleDbCommand(strsql, conn)
        countwait = Convert.ToInt32(cmd1.ExecuteScalar())
        TextBox3.Text = countwait

        conn.Close()

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        'strsql = "SELECT COUNT(*) AS Expr2 FROM  Waiting_List WHERE (VisitingTime = '" & Todaynow & "')" &
        '        " AND (Status = 'meet doctor')"
        strsql = "SELECT  namepatient, QueueNo FROM   Waiting_List WHERE (Status = 'meet doctor') "
        Dim cmd3 As New OleDbCommand(strsql, conn)
        Dim dr As OleDbDataReader
        dr = cmd3.ExecuteReader
        dr.Read()
        TextBox1.Text = dr("namepatient")
        queueNo = dr("QueueNo")
        queueNo = queueNo + 1

        strsql = "SELECT  namepatient FROM   Waiting_List WHERE (QueueNo =" & queueNo & ") "
        Dim cmd4 As New OleDbCommand(strsql, conn)
        Dim dr1 As OleDbDataReader
        dr1 = cmd4.ExecuteReader
        dr1.Read()
        TextBox5.Text = dr1("namepatient")


        'If Expr2 > 0 Then
        '    Try
        '        strsql = "Select NamePatient, QueueNo FROM  Waiting_List WHERE (VisitingTime = '" & Todaynow & "')" &
        '" and (Status = 'Meet Doctor')"
        '        Dim cmd4 As New OleDbCommand(strsql, conn)
        '        Dim dr As OleDbDataReader = cmd.ExecuteReader()
        '        dr.Read()
        '        TextBox1.Text = dr("NamePatient")
        '        NqueueNo = dr("QueueNo") + 1
        '    Catch ex As exception
        '    End Try
        '    Try
        '        strsql = "SELECT NamePatient FROM  Waiting_List WHERE (VisitingTime = '" & Todaynow & "'" &
        '            " AND (Status = 'waiting consultation') AND (QueueNo = " & NqueueNo & ")"
        '        Dim cmd5 As New OleDbCommand(strsql, conn)
        '        Dim dr1 As OleDbDataReader = cmd.ExecuteReader()
        '        dr1.Read()
        '        TextBox5.Text = dr1("NamePatient")
        '    Catch ex As exception
        '    End Try
        'Else
        '    strsql = "SELECT NamePatient FROM  Waiting_List WHERE (VisitingTime = '" & Todaynow & "'" &
        '" AND (Status = 'waiting consultation') AND (QueueNo = 0)"
        '    conn.Close()
        '    If conn.State = ConnectionState.Closed Then
        '        conn.Open()
        '    End If
        '    Dim cmd6 As New OleDbCommand(strsql, conn)
        '    Dim dr2 As OleDbDataReader = cmd.ExecuteReader()
        '    dr2.Read()
        '    TextBox5.Text = dr2("NamePatient")
        'End If

        'If conn.State = ConnectionState.Open Then
        '    conn.Close()
        'End If

    End Sub

    Private Function Database_clinicDataSet2() As Object
        Throw New NotImplementedException()
    End Function
End Class