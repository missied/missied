﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DailyPatientReg
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ptnIdtxt = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.FindBtn = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.RegBtn = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.nameTxt = New System.Windows.Forms.TextBox()
        Me.empIdtxt = New System.Windows.Forms.TextBox()
        Me.compTxt = New System.Windows.Forms.TextBox()
        Me.ExitBtn = New System.Windows.Forms.Button()
        Me.msgLbl = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.insTxt = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.icTxt = New System.Windows.Forms.TextBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ptnIdtxt
        '
        Me.ptnIdtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ptnIdtxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ptnIdtxt.Location = New System.Drawing.Point(96, 19)
        Me.ptnIdtxt.Name = "ptnIdtxt"
        Me.ptnIdtxt.Size = New System.Drawing.Size(102, 26)
        Me.ptnIdtxt.TabIndex = 0
        Me.ptnIdtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(6, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(84, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Patient ID "
        '
        'FindBtn
        '
        Me.FindBtn.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.FindBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.FindBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.FindBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FindBtn.Location = New System.Drawing.Point(213, 19)
        Me.FindBtn.Name = "FindBtn"
        Me.FindBtn.Size = New System.Drawing.Size(57, 26)
        Me.FindBtn.TabIndex = 2
        Me.FindBtn.Text = "Find"
        Me.FindBtn.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(127, 89)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(51, 20)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(104, 194)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 20)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Employee ID"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(88, 247)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(122, 20)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Company Name"
        '
        'RegBtn
        '
        Me.RegBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.RegBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.RegBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RegBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RegBtn.Location = New System.Drawing.Point(70, 364)
        Me.RegBtn.Name = "RegBtn"
        Me.RegBtn.Size = New System.Drawing.Size(82, 33)
        Me.RegBtn.TabIndex = 7
        Me.RegBtn.Text = "Register"
        Me.RegBtn.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.FindBtn)
        Me.GroupBox1.Controls.Add(Me.ptnIdtxt)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 1)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(284, 82)
        Me.GroupBox1.TabIndex = 11
        Me.GroupBox1.TabStop = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(9, 51)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(152, 16)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "or search [Employee ID]"
        '
        'nameTxt
        '
        Me.nameTxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.nameTxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nameTxt.Location = New System.Drawing.Point(12, 112)
        Me.nameTxt.Name = "nameTxt"
        Me.nameTxt.Size = New System.Drawing.Size(284, 26)
        Me.nameTxt.TabIndex = 12
        Me.nameTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'empIdtxt
        '
        Me.empIdtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.empIdtxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.empIdtxt.Location = New System.Drawing.Point(12, 218)
        Me.empIdtxt.Name = "empIdtxt"
        Me.empIdtxt.Size = New System.Drawing.Size(284, 26)
        Me.empIdtxt.TabIndex = 13
        Me.empIdtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'compTxt
        '
        Me.compTxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.compTxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.compTxt.Location = New System.Drawing.Point(12, 271)
        Me.compTxt.Name = "compTxt"
        Me.compTxt.Size = New System.Drawing.Size(284, 26)
        Me.compTxt.TabIndex = 14
        Me.compTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ExitBtn
        '
        Me.ExitBtn.BackColor = System.Drawing.Color.LemonChiffon
        Me.ExitBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ExitBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ExitBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExitBtn.Location = New System.Drawing.Point(158, 364)
        Me.ExitBtn.Name = "ExitBtn"
        Me.ExitBtn.Size = New System.Drawing.Size(82, 33)
        Me.ExitBtn.TabIndex = 15
        Me.ExitBtn.Text = "Exit"
        Me.ExitBtn.UseVisualStyleBackColor = False
        '
        'msgLbl
        '
        Me.msgLbl.AutoSize = True
        Me.msgLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.msgLbl.ForeColor = System.Drawing.Color.Red
        Me.msgLbl.Location = New System.Drawing.Point(22, 402)
        Me.msgLbl.Name = "msgLbl"
        Me.msgLbl.Size = New System.Drawing.Size(0, 16)
        Me.msgLbl.TabIndex = 16
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(88, 299)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(140, 20)
        Me.Label5.TabIndex = 17
        Me.Label5.Text = "Insurance (if any?)"
        '
        'insTxt
        '
        Me.insTxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.insTxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.insTxt.Location = New System.Drawing.Point(12, 324)
        Me.insTxt.Name = "insTxt"
        Me.insTxt.Size = New System.Drawing.Size(284, 26)
        Me.insTxt.TabIndex = 18
        Me.insTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(127, 141)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 20)
        Me.Label6.TabIndex = 19
        Me.Label6.Text = "IC No."
        '
        'icTxt
        '
        Me.icTxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.icTxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.icTxt.Location = New System.Drawing.Point(12, 165)
        Me.icTxt.Name = "icTxt"
        Me.icTxt.Size = New System.Drawing.Size(284, 26)
        Me.icTxt.TabIndex = 20
        Me.icTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Timer1
        '
        '
        'DailyPatientReg
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FloralWhite
        Me.ClientSize = New System.Drawing.Size(312, 425)
        Me.Controls.Add(Me.icTxt)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.insTxt)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.msgLbl)
        Me.Controls.Add(Me.ExitBtn)
        Me.Controls.Add(Me.compTxt)
        Me.Controls.Add(Me.empIdtxt)
        Me.Controls.Add(Me.nameTxt)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.RegBtn)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "DailyPatientReg"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "DailyPatientReg"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ptnIdtxt As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents FindBtn As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents RegBtn As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents nameTxt As TextBox
    Friend WithEvents empIdtxt As TextBox
    Friend WithEvents compTxt As TextBox
    Friend WithEvents ExitBtn As Button
    Friend WithEvents msgLbl As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents insTxt As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents icTxt As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Timer1 As Timer
End Class
