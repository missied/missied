﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PatientList
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Search = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Update = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Database_clinicDataSet2 = New clinic_sys.Database_clinicDataSet2()
        Me.DatabaseclinicDataSet2BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PatientInformationBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Patient_InformationTableAdapter = New clinic_sys.Database_clinicDataSet2TableAdapters.Patient_InformationTableAdapter()
        Me.IDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NamePatientDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DOBDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AgeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AddressDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CityDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PostcodeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PhoneNoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ICNoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GenderDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MaritalStatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.WorkStatusDataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.EmpIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EmployerDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.InsuranceDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BloodTypeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.WeightDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HeightDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Illness1DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Illness2DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Illness3DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Illness4DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Illness5DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Illness6DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Illness7DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Illness8DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Illness9DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Illness10DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RelativeNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RelativePhoneDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PaymentDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RegDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastUpdateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PatientIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Database_clinicDataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DatabaseclinicDataSet2BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PatientInformationBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(100, 12)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(112, 24)
        Me.TextBox1.TabIndex = 0
        '
        'Search
        '
        Me.Search.BackColor = System.Drawing.Color.LemonChiffon
        Me.Search.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Search.Location = New System.Drawing.Point(228, 12)
        Me.Search.Name = "Search"
        Me.Search.Size = New System.Drawing.Size(94, 25)
        Me.Search.TabIndex = 1
        Me.Search.Text = "Find"
        Me.Search.UseVisualStyleBackColor = False
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.White
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn, Me.NamePatientDataGridViewTextBoxColumn, Me.DOBDataGridViewTextBoxColumn, Me.AgeDataGridViewTextBoxColumn, Me.AddressDataGridViewTextBoxColumn, Me.CityDataGridViewTextBoxColumn, Me.PostcodeDataGridViewTextBoxColumn, Me.PhoneNoDataGridViewTextBoxColumn, Me.ICNoDataGridViewTextBoxColumn, Me.GenderDataGridViewTextBoxColumn, Me.MaritalStatusDataGridViewTextBoxColumn, Me.WorkStatusDataGridViewCheckBoxColumn, Me.EmpIDDataGridViewTextBoxColumn, Me.EmployerDataGridViewTextBoxColumn, Me.InsuranceDataGridViewTextBoxColumn, Me.BloodTypeDataGridViewTextBoxColumn, Me.WeightDataGridViewTextBoxColumn, Me.HeightDataGridViewTextBoxColumn, Me.Illness1DataGridViewTextBoxColumn, Me.Illness2DataGridViewTextBoxColumn, Me.Illness3DataGridViewTextBoxColumn, Me.Illness4DataGridViewTextBoxColumn, Me.Illness5DataGridViewTextBoxColumn, Me.Illness6DataGridViewTextBoxColumn, Me.Illness7DataGridViewTextBoxColumn, Me.Illness8DataGridViewTextBoxColumn, Me.Illness9DataGridViewTextBoxColumn, Me.Illness10DataGridViewTextBoxColumn, Me.RelativeNameDataGridViewTextBoxColumn, Me.RelativePhoneDataGridViewTextBoxColumn, Me.PaymentDataGridViewTextBoxColumn, Me.RegDateDataGridViewTextBoxColumn, Me.LastUpdateDataGridViewTextBoxColumn, Me.PatientIDDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.PatientInformationBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(12, 43)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(531, 394)
        Me.DataGridView1.TabIndex = 2
        '
        'Update
        '
        Me.Update.BackColor = System.Drawing.Color.LemonChiffon
        Me.Update.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Update.Location = New System.Drawing.Point(337, 12)
        Me.Update.Name = "Update"
        Me.Update.Size = New System.Drawing.Size(94, 25)
        Me.Update.TabIndex = 3
        Me.Update.Text = "Update"
        Me.Update.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.LemonChiffon
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Location = New System.Drawing.Point(449, 12)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(94, 25)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Exit"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(12, 15)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(71, 18)
        Me.Label5.TabIndex = 33
        Me.Label5.Text = "Patient ID"
        '
        'Database_clinicDataSet2
        '
        Me.Database_clinicDataSet2.DataSetName = "Database_clinicDataSet2"
        Me.Database_clinicDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DatabaseclinicDataSet2BindingSource
        '
        Me.DatabaseclinicDataSet2BindingSource.DataSource = Me.Database_clinicDataSet2
        Me.DatabaseclinicDataSet2BindingSource.Position = 0
        '
        'PatientInformationBindingSource
        '
        Me.PatientInformationBindingSource.DataMember = "Patient_Information"
        Me.PatientInformationBindingSource.DataSource = Me.DatabaseclinicDataSet2BindingSource
        '
        'Patient_InformationTableAdapter
        '
        Me.Patient_InformationTableAdapter.ClearBeforeFill = True
        '
        'IDDataGridViewTextBoxColumn
        '
        Me.IDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        Me.IDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn.Name = "IDDataGridViewTextBoxColumn"
        '
        'NamePatientDataGridViewTextBoxColumn
        '
        Me.NamePatientDataGridViewTextBoxColumn.DataPropertyName = "NamePatient"
        Me.NamePatientDataGridViewTextBoxColumn.HeaderText = "NamePatient"
        Me.NamePatientDataGridViewTextBoxColumn.Name = "NamePatientDataGridViewTextBoxColumn"
        '
        'DOBDataGridViewTextBoxColumn
        '
        Me.DOBDataGridViewTextBoxColumn.DataPropertyName = "DOB"
        Me.DOBDataGridViewTextBoxColumn.HeaderText = "DOB"
        Me.DOBDataGridViewTextBoxColumn.Name = "DOBDataGridViewTextBoxColumn"
        '
        'AgeDataGridViewTextBoxColumn
        '
        Me.AgeDataGridViewTextBoxColumn.DataPropertyName = "Age"
        Me.AgeDataGridViewTextBoxColumn.HeaderText = "Age"
        Me.AgeDataGridViewTextBoxColumn.Name = "AgeDataGridViewTextBoxColumn"
        '
        'AddressDataGridViewTextBoxColumn
        '
        Me.AddressDataGridViewTextBoxColumn.DataPropertyName = "Address"
        Me.AddressDataGridViewTextBoxColumn.HeaderText = "Address"
        Me.AddressDataGridViewTextBoxColumn.Name = "AddressDataGridViewTextBoxColumn"
        '
        'CityDataGridViewTextBoxColumn
        '
        Me.CityDataGridViewTextBoxColumn.DataPropertyName = "City"
        Me.CityDataGridViewTextBoxColumn.HeaderText = "City"
        Me.CityDataGridViewTextBoxColumn.Name = "CityDataGridViewTextBoxColumn"
        '
        'PostcodeDataGridViewTextBoxColumn
        '
        Me.PostcodeDataGridViewTextBoxColumn.DataPropertyName = "Postcode"
        Me.PostcodeDataGridViewTextBoxColumn.HeaderText = "Postcode"
        Me.PostcodeDataGridViewTextBoxColumn.Name = "PostcodeDataGridViewTextBoxColumn"
        '
        'PhoneNoDataGridViewTextBoxColumn
        '
        Me.PhoneNoDataGridViewTextBoxColumn.DataPropertyName = "PhoneNo"
        Me.PhoneNoDataGridViewTextBoxColumn.HeaderText = "PhoneNo"
        Me.PhoneNoDataGridViewTextBoxColumn.Name = "PhoneNoDataGridViewTextBoxColumn"
        '
        'ICNoDataGridViewTextBoxColumn
        '
        Me.ICNoDataGridViewTextBoxColumn.DataPropertyName = "ICNo"
        Me.ICNoDataGridViewTextBoxColumn.HeaderText = "ICNo"
        Me.ICNoDataGridViewTextBoxColumn.Name = "ICNoDataGridViewTextBoxColumn"
        '
        'GenderDataGridViewTextBoxColumn
        '
        Me.GenderDataGridViewTextBoxColumn.DataPropertyName = "Gender"
        Me.GenderDataGridViewTextBoxColumn.HeaderText = "Gender"
        Me.GenderDataGridViewTextBoxColumn.Name = "GenderDataGridViewTextBoxColumn"
        '
        'MaritalStatusDataGridViewTextBoxColumn
        '
        Me.MaritalStatusDataGridViewTextBoxColumn.DataPropertyName = "MaritalStatus"
        Me.MaritalStatusDataGridViewTextBoxColumn.HeaderText = "MaritalStatus"
        Me.MaritalStatusDataGridViewTextBoxColumn.Name = "MaritalStatusDataGridViewTextBoxColumn"
        '
        'WorkStatusDataGridViewCheckBoxColumn
        '
        Me.WorkStatusDataGridViewCheckBoxColumn.DataPropertyName = "WorkStatus"
        Me.WorkStatusDataGridViewCheckBoxColumn.HeaderText = "WorkStatus"
        Me.WorkStatusDataGridViewCheckBoxColumn.Name = "WorkStatusDataGridViewCheckBoxColumn"
        '
        'EmpIDDataGridViewTextBoxColumn
        '
        Me.EmpIDDataGridViewTextBoxColumn.DataPropertyName = "EmpID"
        Me.EmpIDDataGridViewTextBoxColumn.HeaderText = "EmpID"
        Me.EmpIDDataGridViewTextBoxColumn.Name = "EmpIDDataGridViewTextBoxColumn"
        '
        'EmployerDataGridViewTextBoxColumn
        '
        Me.EmployerDataGridViewTextBoxColumn.DataPropertyName = "Employer"
        Me.EmployerDataGridViewTextBoxColumn.HeaderText = "Employer"
        Me.EmployerDataGridViewTextBoxColumn.Name = "EmployerDataGridViewTextBoxColumn"
        '
        'InsuranceDataGridViewTextBoxColumn
        '
        Me.InsuranceDataGridViewTextBoxColumn.DataPropertyName = "Insurance"
        Me.InsuranceDataGridViewTextBoxColumn.HeaderText = "Insurance"
        Me.InsuranceDataGridViewTextBoxColumn.Name = "InsuranceDataGridViewTextBoxColumn"
        '
        'BloodTypeDataGridViewTextBoxColumn
        '
        Me.BloodTypeDataGridViewTextBoxColumn.DataPropertyName = "BloodType"
        Me.BloodTypeDataGridViewTextBoxColumn.HeaderText = "BloodType"
        Me.BloodTypeDataGridViewTextBoxColumn.Name = "BloodTypeDataGridViewTextBoxColumn"
        '
        'WeightDataGridViewTextBoxColumn
        '
        Me.WeightDataGridViewTextBoxColumn.DataPropertyName = "Weight"
        Me.WeightDataGridViewTextBoxColumn.HeaderText = "Weight"
        Me.WeightDataGridViewTextBoxColumn.Name = "WeightDataGridViewTextBoxColumn"
        '
        'HeightDataGridViewTextBoxColumn
        '
        Me.HeightDataGridViewTextBoxColumn.DataPropertyName = "Height"
        Me.HeightDataGridViewTextBoxColumn.HeaderText = "Height"
        Me.HeightDataGridViewTextBoxColumn.Name = "HeightDataGridViewTextBoxColumn"
        '
        'Illness1DataGridViewTextBoxColumn
        '
        Me.Illness1DataGridViewTextBoxColumn.DataPropertyName = "Illness1"
        Me.Illness1DataGridViewTextBoxColumn.HeaderText = "Illness1"
        Me.Illness1DataGridViewTextBoxColumn.Name = "Illness1DataGridViewTextBoxColumn"
        '
        'Illness2DataGridViewTextBoxColumn
        '
        Me.Illness2DataGridViewTextBoxColumn.DataPropertyName = "Illness2"
        Me.Illness2DataGridViewTextBoxColumn.HeaderText = "Illness2"
        Me.Illness2DataGridViewTextBoxColumn.Name = "Illness2DataGridViewTextBoxColumn"
        '
        'Illness3DataGridViewTextBoxColumn
        '
        Me.Illness3DataGridViewTextBoxColumn.DataPropertyName = "Illness3"
        Me.Illness3DataGridViewTextBoxColumn.HeaderText = "Illness3"
        Me.Illness3DataGridViewTextBoxColumn.Name = "Illness3DataGridViewTextBoxColumn"
        '
        'Illness4DataGridViewTextBoxColumn
        '
        Me.Illness4DataGridViewTextBoxColumn.DataPropertyName = "Illness4"
        Me.Illness4DataGridViewTextBoxColumn.HeaderText = "Illness4"
        Me.Illness4DataGridViewTextBoxColumn.Name = "Illness4DataGridViewTextBoxColumn"
        '
        'Illness5DataGridViewTextBoxColumn
        '
        Me.Illness5DataGridViewTextBoxColumn.DataPropertyName = "Illness5"
        Me.Illness5DataGridViewTextBoxColumn.HeaderText = "Illness5"
        Me.Illness5DataGridViewTextBoxColumn.Name = "Illness5DataGridViewTextBoxColumn"
        '
        'Illness6DataGridViewTextBoxColumn
        '
        Me.Illness6DataGridViewTextBoxColumn.DataPropertyName = "Illness6"
        Me.Illness6DataGridViewTextBoxColumn.HeaderText = "Illness6"
        Me.Illness6DataGridViewTextBoxColumn.Name = "Illness6DataGridViewTextBoxColumn"
        '
        'Illness7DataGridViewTextBoxColumn
        '
        Me.Illness7DataGridViewTextBoxColumn.DataPropertyName = "Illness7"
        Me.Illness7DataGridViewTextBoxColumn.HeaderText = "Illness7"
        Me.Illness7DataGridViewTextBoxColumn.Name = "Illness7DataGridViewTextBoxColumn"
        '
        'Illness8DataGridViewTextBoxColumn
        '
        Me.Illness8DataGridViewTextBoxColumn.DataPropertyName = "Illness8"
        Me.Illness8DataGridViewTextBoxColumn.HeaderText = "Illness8"
        Me.Illness8DataGridViewTextBoxColumn.Name = "Illness8DataGridViewTextBoxColumn"
        '
        'Illness9DataGridViewTextBoxColumn
        '
        Me.Illness9DataGridViewTextBoxColumn.DataPropertyName = "Illness9"
        Me.Illness9DataGridViewTextBoxColumn.HeaderText = "Illness9"
        Me.Illness9DataGridViewTextBoxColumn.Name = "Illness9DataGridViewTextBoxColumn"
        '
        'Illness10DataGridViewTextBoxColumn
        '
        Me.Illness10DataGridViewTextBoxColumn.DataPropertyName = "Illness10"
        Me.Illness10DataGridViewTextBoxColumn.HeaderText = "Illness10"
        Me.Illness10DataGridViewTextBoxColumn.Name = "Illness10DataGridViewTextBoxColumn"
        '
        'RelativeNameDataGridViewTextBoxColumn
        '
        Me.RelativeNameDataGridViewTextBoxColumn.DataPropertyName = "RelativeName"
        Me.RelativeNameDataGridViewTextBoxColumn.HeaderText = "RelativeName"
        Me.RelativeNameDataGridViewTextBoxColumn.Name = "RelativeNameDataGridViewTextBoxColumn"
        '
        'RelativePhoneDataGridViewTextBoxColumn
        '
        Me.RelativePhoneDataGridViewTextBoxColumn.DataPropertyName = "RelativePhone"
        Me.RelativePhoneDataGridViewTextBoxColumn.HeaderText = "RelativePhone"
        Me.RelativePhoneDataGridViewTextBoxColumn.Name = "RelativePhoneDataGridViewTextBoxColumn"
        '
        'PaymentDataGridViewTextBoxColumn
        '
        Me.PaymentDataGridViewTextBoxColumn.DataPropertyName = "Payment"
        Me.PaymentDataGridViewTextBoxColumn.HeaderText = "Payment"
        Me.PaymentDataGridViewTextBoxColumn.Name = "PaymentDataGridViewTextBoxColumn"
        '
        'RegDateDataGridViewTextBoxColumn
        '
        Me.RegDateDataGridViewTextBoxColumn.DataPropertyName = "RegDate"
        Me.RegDateDataGridViewTextBoxColumn.HeaderText = "RegDate"
        Me.RegDateDataGridViewTextBoxColumn.Name = "RegDateDataGridViewTextBoxColumn"
        '
        'LastUpdateDataGridViewTextBoxColumn
        '
        Me.LastUpdateDataGridViewTextBoxColumn.DataPropertyName = "LastUpdate"
        Me.LastUpdateDataGridViewTextBoxColumn.HeaderText = "LastUpdate"
        Me.LastUpdateDataGridViewTextBoxColumn.Name = "LastUpdateDataGridViewTextBoxColumn"
        '
        'PatientIDDataGridViewTextBoxColumn
        '
        Me.PatientIDDataGridViewTextBoxColumn.DataPropertyName = "PatientID"
        Me.PatientIDDataGridViewTextBoxColumn.HeaderText = "PatientID"
        Me.PatientIDDataGridViewTextBoxColumn.Name = "PatientIDDataGridViewTextBoxColumn"
        '
        'PatientList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FloralWhite
        Me.ClientSize = New System.Drawing.Size(564, 450)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Update)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Search)
        Me.Controls.Add(Me.TextBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "PatientList"
        Me.Text = "PatientList"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Database_clinicDataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DatabaseclinicDataSet2BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PatientInformationBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Search As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Update As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents DatabaseclinicDataSet2BindingSource As BindingSource
    Friend WithEvents Database_clinicDataSet2 As Database_clinicDataSet2
    Friend WithEvents PatientInformationBindingSource As BindingSource
    Friend WithEvents Patient_InformationTableAdapter As Database_clinicDataSet2TableAdapters.Patient_InformationTableAdapter
    Friend WithEvents IDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NamePatientDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DOBDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AgeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AddressDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CityDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PostcodeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PhoneNoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ICNoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents GenderDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents MaritalStatusDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents WorkStatusDataGridViewCheckBoxColumn As DataGridViewCheckBoxColumn
    Friend WithEvents EmpIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents EmployerDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents InsuranceDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BloodTypeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents WeightDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents HeightDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Illness1DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Illness2DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Illness3DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Illness4DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Illness5DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Illness6DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Illness7DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Illness8DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Illness9DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Illness10DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents RelativeNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents RelativePhoneDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PaymentDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents RegDateDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents LastUpdateDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PatientIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
