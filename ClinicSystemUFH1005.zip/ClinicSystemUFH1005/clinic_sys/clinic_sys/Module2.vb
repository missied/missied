﻿Module Module2
    'for all form
    Public XX As String ' represent userid
    Public YY As String 'to select designation during login

    'patient registration form
    Public ptnName, relName As String
    Public dobDate As String
    Public Age As Integer
    Public address, city As String
    Public Pcode As Integer
    Public ptnPhone As Integer
    Public ICNo As String
    Public Gender, M_status As String
    Public Work As Boolean
    Public EmpIDx, Empx, Ins As String
    Public blood As String
    Public Hght, Wght As Integer
    Public ill(15) As String
    Public relPhone As Integer
    Public pay As String
    Public ptnID As Integer

    'daily registration form
    Public queueNo As Int16
    Public consultationTime As String
    Public status As String

    Public drDuty As String





End Module