﻿Namespace clinic_sys
    Friend Class Database_clinicDataSet2
        Inherits clinic_sys_Display.Database_clinicDataSet2
    End Class
End Namespace
