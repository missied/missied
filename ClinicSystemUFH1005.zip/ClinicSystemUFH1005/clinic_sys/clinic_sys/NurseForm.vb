﻿Imports System.Data.Common
Imports System.Data.OleDb

Public Class NurseForm

    Dim da As New OleDbDataAdapter
    Dim dset As New DataSet
    Dim VisitTime As String = Now.ToString("d")
    Dim count As Integer
    Dim ttlcount As Integer
    Dim paycount As Integer

    Private Sub NurseForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim EmpName, EmpNo, Designation As String

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        Me.Waiting_ListTableAdapter.Fill(Me.Database_clinicDataSet.Waiting_List)
        strsql = "select * from Waiting_List where visitingtime = '" & VisitTime & "'"
        da = New OleDbDataAdapter(strsql, conn)
        dset = New DataSet
        da.Fill(dset, "Waiting_List")
        DataGridView1.DataSource = dset.Tables("Waiting_List")

        strsql = "select name,designation,EmployeeID from Employee_Information where userid = '" & XX & "'"
        Dim cmd As New OleDbCommand(strsql, conn)
        Dim dr As OleDbDataReader
        dr = cmd.ExecuteReader

        If dr.Read() Then
            EmpNo = dr("EmployeeID")
            EmpName = dr("name")
            Designation = dr("designation")
            NurseName.Text = EmpName
            EmpNoTxt.Text = EmpNo
            userIDtxt.Text = XX
            JobTxt.Text = Designation
            If TextBox2.Text = Nothing Then
                MsgBox("Please don't forget to input the doctor's on duty...")
            Else
            End If
            If JobTxt.Text = "Admin" Then
                    BtnMaintenance.Visible = True
                End If
            Else
                MsgBox("No data found! Please call your admin to check database.")
        End If
        conn.Close()

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        strsql = "SELECT COUNT(*) AS Expr1 FROM  Waiting_List WHERE (VisitingTime = '" & VisitTime & "')" &
                " and (Status = 'Waiting consultation')"
        Dim cmd1 As New OleDbCommand(strsql, conn)
        count = Convert.ToInt32(cmd1.ExecuteScalar())
        WaitTxt.Text = count

        strsql = "SELECT COUNT(*) AS Expr1 FROM  Waiting_List"
        Dim cmd2 As New OleDbCommand(strsql, conn)
        ttlcount = Convert.ToInt32(cmd2.ExecuteScalar())
        Visittxt.Text = ttlcount

        strsql = "SELECT COUNT(*) AS Expr1 FROM  Waiting_List WHERE (VisitingTime = '" & VisitTime & "')" &
                " and (Status = 'Done')"
        Dim cmd3 As New OleDbCommand(strsql, conn)
        paycount = Convert.ToInt32(cmd3.ExecuteScalar())
        paytxt.Text = paycount

        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles NewBtn.Click
        PatientReg.Show()
        Me.Hide()
    End Sub

    Private Sub ExittBtn_Click(sender As Object, e As EventArgs) Handles ExittBtn.Click
        Me.Close()
        LoginForm.Show()
        Try
            strsql = "UPDATE Login_table" & " SET Status = no" & "  WHERE (UserID ='" & XX & "')"
            Dim cmd As New OleDbCommand(strsql, conn)
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show("There was an error processing your request. Please try again." & vbCrLf & vbCrLf &
                            "Original Error:" & vbCrLf & vbCrLf & ex.ToString, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        LoginForm.TextBox1.Clear()
        LoginForm.TextBox2.Clear()
        TextBox2.Clear()

        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub RegBtn_Click(sender As Object, e As EventArgs) Handles RegBtn.Click
        DailyPatientReg.Show()
        Me.Close()
    End Sub

    Private Sub PatListBtn_Click(sender As Object, e As EventArgs) Handles PatListBtn.Click
        PatientList.Show()
    End Sub

    Private Sub DrBtn_Click(sender As Object, e As EventArgs) Handles DrBtn.Click
        DrOnduty.Show()
    End Sub

    Private Sub PayBtn_Click(sender As Object, e As EventArgs) Handles PayBtn.Click
        PaymentForm.Show()
    End Sub
End Class