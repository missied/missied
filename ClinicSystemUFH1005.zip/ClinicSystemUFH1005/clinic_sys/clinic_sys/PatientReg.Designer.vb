﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class PatientReg
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim Label26 As System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.HeartAttc = New System.Windows.Forms.CheckBox()
        Me.KidneyDis = New System.Windows.Forms.CheckBox()
        Me.HiChole = New System.Windows.Forms.CheckBox()
        Me.Allergies = New System.Windows.Forms.CheckBox()
        Me.HiBP = New System.Windows.Forms.CheckBox()
        Me.Anemia = New System.Windows.Forms.CheckBox()
        Me.DiaType2 = New System.Windows.Forms.CheckBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.DiaType1 = New System.Windows.Forms.CheckBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Cancer = New System.Windows.Forms.CheckBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.BloodClot = New System.Windows.Forms.CheckBox()
        Me.BloodTxt = New System.Windows.Forms.TextBox()
        Me.Adhd = New System.Windows.Forms.CheckBox()
        Me.HeightTxt = New System.Windows.Forms.TextBox()
        Me.Anxiety = New System.Windows.Forms.CheckBox()
        Me.WeightTxt = New System.Windows.Forms.TextBox()
        Me.Arthitis = New System.Windows.Forms.CheckBox()
        Me.Asthma = New System.Windows.Forms.CheckBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.MrrChkBox = New System.Windows.Forms.CheckBox()
        Me.IcNoTxt = New System.Windows.Forms.TextBox()
        Me.Citytxt = New System.Windows.Forms.TextBox()
        Me.SngChkBox = New System.Windows.Forms.CheckBox()
        Me.FemaleChkBox = New System.Windows.Forms.CheckBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Agetxt = New System.Windows.Forms.TextBox()
        Me.MaleChkBox = New System.Windows.Forms.CheckBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Address1txt = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Postcodetxt = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.phonePtnTxt = New System.Windows.Forms.TextBox()
        Me.DOBtxt = New System.Windows.Forms.TextBox()
        Me.PatientName = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.No = New System.Windows.Forms.RadioButton()
        Me.Yes = New System.Windows.Forms.RadioButton()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.InsTypetxt = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.EmpIDtxt = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.EmpAddTxt = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.CashRB = New System.Windows.Forms.RadioButton()
        Me.InsRB = New System.Windows.Forms.RadioButton()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.SaveBtn = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.RelNameTxt = New System.Windows.Forms.TextBox()
        Me.phoneRelTxt = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.exittBtn = New System.Windows.Forms.Button()
        Me.UpdBtn = New System.Windows.Forms.Button()
        Me.PtnIDTxt = New System.Windows.Forms.TextBox()
        Me.msgLbl = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Label26 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label26
        '
        Label26.AutoSize = True
        Label26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label26.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Label26.Location = New System.Drawing.Point(12, 575)
        Label26.Name = "Label26"
        Label26.Size = New System.Drawing.Size(82, 22)
        Label26.TabIndex = 105
        Label26.Text = "Patient ID"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.HeartAttc)
        Me.GroupBox1.Controls.Add(Me.KidneyDis)
        Me.GroupBox1.Controls.Add(Me.HiChole)
        Me.GroupBox1.Controls.Add(Me.Allergies)
        Me.GroupBox1.Controls.Add(Me.HiBP)
        Me.GroupBox1.Controls.Add(Me.Anemia)
        Me.GroupBox1.Controls.Add(Me.DiaType2)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.DiaType1)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.Label22)
        Me.GroupBox1.Controls.Add(Me.Cancer)
        Me.GroupBox1.Controls.Add(Me.Label21)
        Me.GroupBox1.Controls.Add(Me.BloodClot)
        Me.GroupBox1.Controls.Add(Me.BloodTxt)
        Me.GroupBox1.Controls.Add(Me.Adhd)
        Me.GroupBox1.Controls.Add(Me.HeightTxt)
        Me.GroupBox1.Controls.Add(Me.Anxiety)
        Me.GroupBox1.Controls.Add(Me.WeightTxt)
        Me.GroupBox1.Controls.Add(Me.Arthitis)
        Me.GroupBox1.Controls.Add(Me.Asthma)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Location = New System.Drawing.Point(397, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(379, 341)
        Me.GroupBox1.TabIndex = 94
        Me.GroupBox1.TabStop = False
        '
        'HeartAttc
        '
        Me.HeartAttc.AutoSize = True
        Me.HeartAttc.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HeartAttc.Location = New System.Drawing.Point(20, 307)
        Me.HeartAttc.Name = "HeartAttc"
        Me.HeartAttc.Size = New System.Drawing.Size(108, 22)
        Me.HeartAttc.TabIndex = 138
        Me.HeartAttc.Text = "Heart Attack"
        Me.HeartAttc.UseVisualStyleBackColor = True
        '
        'KidneyDis
        '
        Me.KidneyDis.AutoSize = True
        Me.KidneyDis.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KidneyDis.Location = New System.Drawing.Point(215, 305)
        Me.KidneyDis.Name = "KidneyDis"
        Me.KidneyDis.Size = New System.Drawing.Size(129, 22)
        Me.KidneyDis.TabIndex = 139
        Me.KidneyDis.Text = "Kidney Disease"
        Me.KidneyDis.UseVisualStyleBackColor = True
        '
        'HiChole
        '
        Me.HiChole.AutoSize = True
        Me.HiChole.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HiChole.Location = New System.Drawing.Point(215, 279)
        Me.HiChole.Name = "HiChole"
        Me.HiChole.Size = New System.Drawing.Size(137, 22)
        Me.HiChole.TabIndex = 137
        Me.HiChole.Text = "High Cholesterol"
        Me.HiChole.UseVisualStyleBackColor = True
        '
        'Allergies
        '
        Me.Allergies.AutoSize = True
        Me.Allergies.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Allergies.Location = New System.Drawing.Point(216, 137)
        Me.Allergies.Name = "Allergies"
        Me.Allergies.Size = New System.Drawing.Size(82, 22)
        Me.Allergies.TabIndex = 128
        Me.Allergies.Text = "Allergies"
        Me.Allergies.UseVisualStyleBackColor = True
        '
        'HiBP
        '
        Me.HiBP.AutoSize = True
        Me.HiBP.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HiBP.Location = New System.Drawing.Point(19, 279)
        Me.HiBP.Name = "HiBP"
        Me.HiBP.Size = New System.Drawing.Size(164, 22)
        Me.HiBP.TabIndex = 136
        Me.HiBP.Text = "High Blood Pressure"
        Me.HiBP.UseVisualStyleBackColor = True
        '
        'Anemia
        '
        Me.Anemia.AutoSize = True
        Me.Anemia.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Anemia.Location = New System.Drawing.Point(20, 137)
        Me.Anemia.Name = "Anemia"
        Me.Anemia.Size = New System.Drawing.Size(76, 22)
        Me.Anemia.TabIndex = 110
        Me.Anemia.Text = "Anemia"
        Me.Anemia.UseVisualStyleBackColor = True
        '
        'DiaType2
        '
        Me.DiaType2.AutoSize = True
        Me.DiaType2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DiaType2.Location = New System.Drawing.Point(216, 250)
        Me.DiaType2.Name = "DiaType2"
        Me.DiaType2.Size = New System.Drawing.Size(133, 22)
        Me.DiaType2.TabIndex = 135
        Me.DiaType2.Text = "Diabetes Type 2"
        Me.DiaType2.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(16, 16)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(157, 20)
        Me.Label15.TabIndex = 127
        Me.Label15.Text = "MEDICAL HISTORY"
        '
        'DiaType1
        '
        Me.DiaType1.AutoSize = True
        Me.DiaType1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DiaType1.Location = New System.Drawing.Point(19, 251)
        Me.DiaType1.Name = "DiaType1"
        Me.DiaType1.Size = New System.Drawing.Size(133, 22)
        Me.DiaType1.TabIndex = 134
        Me.DiaType1.Text = "Diabetes Type 1"
        Me.DiaType1.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(15, 114)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(194, 20)
        Me.Label13.TabIndex = 126
        Me.Label13.Text = "Illness Information (if any):"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(15, 53)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(88, 20)
        Me.Label22.TabIndex = 125
        Me.Label22.Text = "Blood Type"
        '
        'Cancer
        '
        Me.Cancer.AutoSize = True
        Me.Cancer.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cancer.Location = New System.Drawing.Point(216, 222)
        Me.Cancer.Name = "Cancer"
        Me.Cancer.Size = New System.Drawing.Size(75, 22)
        Me.Cancer.TabIndex = 133
        Me.Cancer.Text = "Cancer"
        Me.Cancer.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(264, 50)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(91, 20)
        Me.Label21.TabIndex = 124
        Me.Label21.Text = "Height (cm)"
        '
        'BloodClot
        '
        Me.BloodClot.AutoSize = True
        Me.BloodClot.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BloodClot.Location = New System.Drawing.Point(19, 223)
        Me.BloodClot.Name = "BloodClot"
        Me.BloodClot.Size = New System.Drawing.Size(105, 22)
        Me.BloodClot.TabIndex = 129
        Me.BloodClot.Text = "Blood Clots"
        Me.BloodClot.UseVisualStyleBackColor = True
        '
        'BloodTxt
        '
        Me.BloodTxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BloodTxt.Location = New System.Drawing.Point(20, 82)
        Me.BloodTxt.Name = "BloodTxt"
        Me.BloodTxt.Size = New System.Drawing.Size(75, 26)
        Me.BloodTxt.TabIndex = 123
        '
        'Adhd
        '
        Me.Adhd.AutoSize = True
        Me.Adhd.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Adhd.Location = New System.Drawing.Point(216, 194)
        Me.Adhd.Name = "Adhd"
        Me.Adhd.Size = New System.Drawing.Size(104, 22)
        Me.Adhd.TabIndex = 132
        Me.Adhd.Text = "ADD/ADHD"
        Me.Adhd.UseVisualStyleBackColor = True
        '
        'HeightTxt
        '
        Me.HeightTxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HeightTxt.Location = New System.Drawing.Point(268, 79)
        Me.HeightTxt.Name = "HeightTxt"
        Me.HeightTxt.Size = New System.Drawing.Size(76, 26)
        Me.HeightTxt.TabIndex = 122
        '
        'Anxiety
        '
        Me.Anxiety.AutoSize = True
        Me.Anxiety.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Anxiety.Location = New System.Drawing.Point(19, 194)
        Me.Anxiety.Name = "Anxiety"
        Me.Anxiety.Size = New System.Drawing.Size(153, 22)
        Me.Anxiety.TabIndex = 131
        Me.Anxiety.Text = "Anxiety/Depression"
        Me.Anxiety.UseVisualStyleBackColor = True
        '
        'WeightTxt
        '
        Me.WeightTxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.WeightTxt.Location = New System.Drawing.Point(147, 79)
        Me.WeightTxt.Name = "WeightTxt"
        Me.WeightTxt.Size = New System.Drawing.Size(76, 26)
        Me.WeightTxt.TabIndex = 121
        '
        'Arthitis
        '
        Me.Arthitis.AutoSize = True
        Me.Arthitis.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Arthitis.Location = New System.Drawing.Point(216, 165)
        Me.Arthitis.Name = "Arthitis"
        Me.Arthitis.Size = New System.Drawing.Size(71, 22)
        Me.Arthitis.TabIndex = 130
        Me.Arthitis.Text = "Arthitis"
        Me.Arthitis.UseVisualStyleBackColor = True
        '
        'Asthma
        '
        Me.Asthma.AutoSize = True
        Me.Asthma.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Asthma.Location = New System.Drawing.Point(20, 165)
        Me.Asthma.Name = "Asthma"
        Me.Asthma.Size = New System.Drawing.Size(77, 22)
        Me.Asthma.TabIndex = 129
        Me.Asthma.Text = "Asthma"
        Me.Asthma.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(143, 50)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(90, 20)
        Me.Label12.TabIndex = 120
        Me.Label12.Text = "Weight (kg)"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.MrrChkBox)
        Me.GroupBox2.Controls.Add(Me.IcNoTxt)
        Me.GroupBox2.Controls.Add(Me.Citytxt)
        Me.GroupBox2.Controls.Add(Me.SngChkBox)
        Me.GroupBox2.Controls.Add(Me.FemaleChkBox)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Agetxt)
        Me.GroupBox2.Controls.Add(Me.MaleChkBox)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.Address1txt)
        Me.GroupBox2.Controls.Add(Me.Label18)
        Me.GroupBox2.Controls.Add(Me.Postcodetxt)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.phonePtnTxt)
        Me.GroupBox2.Controls.Add(Me.DOBtxt)
        Me.GroupBox2.Controls.Add(Me.PatientName)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(379, 341)
        Me.GroupBox2.TabIndex = 95
        Me.GroupBox2.TabStop = False
        '
        'MrrChkBox
        '
        Me.MrrChkBox.AutoSize = True
        Me.MrrChkBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MrrChkBox.Location = New System.Drawing.Point(224, 305)
        Me.MrrChkBox.Name = "MrrChkBox"
        Me.MrrChkBox.Size = New System.Drawing.Size(77, 22)
        Me.MrrChkBox.TabIndex = 110
        Me.MrrChkBox.Text = "Married"
        Me.MrrChkBox.UseVisualStyleBackColor = True
        '
        'IcNoTxt
        '
        Me.IcNoTxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IcNoTxt.Location = New System.Drawing.Point(100, 242)
        Me.IcNoTxt.Name = "IcNoTxt"
        Me.IcNoTxt.Size = New System.Drawing.Size(264, 26)
        Me.IcNoTxt.TabIndex = 91
        '
        'Citytxt
        '
        Me.Citytxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Citytxt.Location = New System.Drawing.Point(252, 178)
        Me.Citytxt.Name = "Citytxt"
        Me.Citytxt.Size = New System.Drawing.Size(113, 26)
        Me.Citytxt.TabIndex = 103
        '
        'SngChkBox
        '
        Me.SngChkBox.AutoSize = True
        Me.SngChkBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SngChkBox.Location = New System.Drawing.Point(133, 305)
        Me.SngChkBox.Name = "SngChkBox"
        Me.SngChkBox.Size = New System.Drawing.Size(67, 22)
        Me.SngChkBox.TabIndex = 108
        Me.SngChkBox.Text = "Single"
        Me.SngChkBox.UseVisualStyleBackColor = True
        '
        'FemaleChkBox
        '
        Me.FemaleChkBox.AutoSize = True
        Me.FemaleChkBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FemaleChkBox.Location = New System.Drawing.Point(224, 274)
        Me.FemaleChkBox.Name = "FemaleChkBox"
        Me.FemaleChkBox.Size = New System.Drawing.Size(76, 22)
        Me.FemaleChkBox.TabIndex = 109
        Me.FemaleChkBox.Text = "Female"
        Me.FemaleChkBox.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(211, 184)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(35, 20)
        Me.Label8.TabIndex = 102
        Me.Label8.Text = "City"
        '
        'Agetxt
        '
        Me.Agetxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Agetxt.Location = New System.Drawing.Point(278, 82)
        Me.Agetxt.Name = "Agetxt"
        Me.Agetxt.Size = New System.Drawing.Size(86, 26)
        Me.Agetxt.TabIndex = 98
        '
        'MaleChkBox
        '
        Me.MaleChkBox.AutoSize = True
        Me.MaleChkBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MaleChkBox.Location = New System.Drawing.Point(133, 274)
        Me.MaleChkBox.Name = "MaleChkBox"
        Me.MaleChkBox.Size = New System.Drawing.Size(59, 22)
        Me.MaleChkBox.TabIndex = 100
        Me.MaleChkBox.Text = "Male"
        Me.MaleChkBox.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(234, 85)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 20)
        Me.Label2.TabIndex = 97
        Me.Label2.Text = "Age"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(9, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(211, 20)
        Me.Label1.TabIndex = 96
        Me.Label1.Text = "PERSONAL INFORMATION"
        '
        'Address1txt
        '
        Me.Address1txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Address1txt.Location = New System.Drawing.Point(101, 114)
        Me.Address1txt.Multiline = True
        Me.Address1txt.Name = "Address1txt"
        Me.Address1txt.Size = New System.Drawing.Size(264, 58)
        Me.Address1txt.TabIndex = 95
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(11, 117)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(68, 20)
        Me.Label18.TabIndex = 94
        Me.Label18.Text = "Address"
        '
        'Postcodetxt
        '
        Me.Postcodetxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Postcodetxt.Location = New System.Drawing.Point(101, 178)
        Me.Postcodetxt.Name = "Postcodetxt"
        Me.Postcodetxt.Size = New System.Drawing.Size(95, 26)
        Me.Postcodetxt.TabIndex = 93
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(9, 181)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(76, 20)
        Me.Label16.TabIndex = 92
        Me.Label16.Text = "Postcode"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(11, 305)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(107, 20)
        Me.Label11.TabIndex = 90
        Me.Label11.Text = "Marital Status"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(11, 245)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(53, 20)
        Me.Label10.TabIndex = 89
        Me.Label10.Text = "IC. No"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(11, 213)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(83, 20)
        Me.Label6.TabIndex = 88
        Me.Label6.Text = "Phone No."
        '
        'phonePtnTxt
        '
        Me.phonePtnTxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.phonePtnTxt.Location = New System.Drawing.Point(100, 210)
        Me.phonePtnTxt.Name = "phonePtnTxt"
        Me.phonePtnTxt.Size = New System.Drawing.Size(264, 26)
        Me.phonePtnTxt.TabIndex = 87
        '
        'DOBtxt
        '
        Me.DOBtxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DOBtxt.Location = New System.Drawing.Point(100, 82)
        Me.DOBtxt.Name = "DOBtxt"
        Me.DOBtxt.Size = New System.Drawing.Size(118, 26)
        Me.DOBtxt.TabIndex = 86
        '
        'PatientName
        '
        Me.PatientName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PatientName.Location = New System.Drawing.Point(100, 50)
        Me.PatientName.Name = "PatientName"
        Me.PatientName.Size = New System.Drawing.Size(264, 26)
        Me.PatientName.TabIndex = 85
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(11, 274)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(63, 20)
        Me.Label5.TabIndex = 84
        Me.Label5.Text = "Gender"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(9, 85)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 20)
        Me.Label4.TabIndex = 83
        Me.Label4.Text = "DOB"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(9, 53)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 20)
        Me.Label3.TabIndex = 82
        Me.Label3.Text = "Name"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.No)
        Me.GroupBox3.Controls.Add(Me.Yes)
        Me.GroupBox3.Controls.Add(Me.Label20)
        Me.GroupBox3.Controls.Add(Me.InsTypetxt)
        Me.GroupBox3.Controls.Add(Me.Label19)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.EmpIDtxt)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.EmpAddTxt)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 359)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(379, 210)
        Me.GroupBox3.TabIndex = 96
        Me.GroupBox3.TabStop = False
        '
        'No
        '
        Me.No.AutoSize = True
        Me.No.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.No.Location = New System.Drawing.Point(210, 46)
        Me.No.Name = "No"
        Me.No.Size = New System.Drawing.Size(46, 22)
        Me.No.TabIndex = 99
        Me.No.TabStop = True
        Me.No.Text = "No"
        Me.No.UseVisualStyleBackColor = True
        '
        'Yes
        '
        Me.Yes.AutoSize = True
        Me.Yes.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Yes.Location = New System.Drawing.Point(133, 46)
        Me.Yes.Name = "Yes"
        Me.Yes.Size = New System.Drawing.Size(51, 22)
        Me.Yes.TabIndex = 98
        Me.Yes.TabStop = True
        Me.Yes.Text = "Yes"
        Me.Yes.UseVisualStyleBackColor = True
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(6, 46)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(118, 20)
        Me.Label20.TabIndex = 97
        Me.Label20.Text = "Working Status"
        '
        'InsTypetxt
        '
        Me.InsTypetxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InsTypetxt.Location = New System.Drawing.Point(102, 169)
        Me.InsTypetxt.Name = "InsTypetxt"
        Me.InsTypetxt.Size = New System.Drawing.Size(263, 26)
        Me.InsTypetxt.TabIndex = 96
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(6, 172)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(80, 20)
        Me.Label19.TabIndex = 95
        Me.Label19.Text = "Insurance"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(6, 16)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(176, 20)
        Me.Label9.TabIndex = 93
        Me.Label9.Text = "PANEL INFORMATION"
        '
        'EmpIDtxt
        '
        Me.EmpIDtxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmpIDtxt.Location = New System.Drawing.Point(102, 73)
        Me.EmpIDtxt.Name = "EmpIDtxt"
        Me.EmpIDtxt.Size = New System.Drawing.Size(118, 26)
        Me.EmpIDtxt.TabIndex = 92
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(6, 76)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(100, 20)
        Me.Label7.TabIndex = 91
        Me.Label7.Text = "Employee ID"
        '
        'EmpAddTxt
        '
        Me.EmpAddTxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmpAddTxt.Location = New System.Drawing.Point(102, 105)
        Me.EmpAddTxt.Multiline = True
        Me.EmpAddTxt.Name = "EmpAddTxt"
        Me.EmpAddTxt.Size = New System.Drawing.Size(263, 58)
        Me.EmpAddTxt.TabIndex = 90
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(6, 105)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(75, 20)
        Me.Label14.TabIndex = 89
        Me.Label14.Text = "Employer"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.CashRB)
        Me.GroupBox4.Controls.Add(Me.InsRB)
        Me.GroupBox4.Controls.Add(Me.Label17)
        Me.GroupBox4.Location = New System.Drawing.Point(397, 359)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(379, 79)
        Me.GroupBox4.TabIndex = 100
        Me.GroupBox4.TabStop = False
        '
        'CashRB
        '
        Me.CashRB.AutoSize = True
        Me.CashRB.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CashRB.Location = New System.Drawing.Point(188, 46)
        Me.CashRB.Name = "CashRB"
        Me.CashRB.Size = New System.Drawing.Size(97, 22)
        Me.CashRB.TabIndex = 99
        Me.CashRB.TabStop = True
        Me.CashRB.Text = "Cash/Card"
        Me.CashRB.UseVisualStyleBackColor = True
        '
        'InsRB
        '
        Me.InsRB.AutoSize = True
        Me.InsRB.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InsRB.Location = New System.Drawing.Point(19, 45)
        Me.InsRB.Name = "InsRB"
        Me.InsRB.Size = New System.Drawing.Size(90, 22)
        Me.InsRB.TabIndex = 98
        Me.InsRB.TabStop = True
        Me.InsRB.Text = "Insurance"
        Me.InsRB.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(6, 16)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(200, 20)
        Me.Label17.TabIndex = 93
        Me.Label17.Text = "PAYMENT INFORMATION"
        '
        'SaveBtn
        '
        Me.SaveBtn.BackColor = System.Drawing.Color.PaleGreen
        Me.SaveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.SaveBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SaveBtn.Location = New System.Drawing.Point(552, 575)
        Me.SaveBtn.Name = "SaveBtn"
        Me.SaveBtn.Size = New System.Drawing.Size(106, 38)
        Me.SaveBtn.TabIndex = 102
        Me.SaveBtn.Text = "Save"
        Me.SaveBtn.UseVisualStyleBackColor = False
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label25)
        Me.GroupBox5.Controls.Add(Me.RelNameTxt)
        Me.GroupBox5.Controls.Add(Me.phoneRelTxt)
        Me.GroupBox5.Controls.Add(Me.Label24)
        Me.GroupBox5.Controls.Add(Me.Label23)
        Me.GroupBox5.Location = New System.Drawing.Point(397, 444)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(379, 125)
        Me.GroupBox5.TabIndex = 101
        Me.GroupBox5.TabStop = False
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(11, 74)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(83, 20)
        Me.Label25.TabIndex = 107
        Me.Label25.Text = "Phone No."
        '
        'RelNameTxt
        '
        Me.RelNameTxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RelNameTxt.Location = New System.Drawing.Point(100, 39)
        Me.RelNameTxt.Name = "RelNameTxt"
        Me.RelNameTxt.Size = New System.Drawing.Size(264, 26)
        Me.RelNameTxt.TabIndex = 107
        '
        'phoneRelTxt
        '
        Me.phoneRelTxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.phoneRelTxt.Location = New System.Drawing.Point(100, 71)
        Me.phoneRelTxt.Name = "phoneRelTxt"
        Me.phoneRelTxt.Size = New System.Drawing.Size(264, 26)
        Me.phoneRelTxt.TabIndex = 106
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(9, 42)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(51, 20)
        Me.Label24.TabIndex = 106
        Me.Label24.Text = "Name"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(6, 16)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(203, 20)
        Me.Label23.TabIndex = 93
        Me.Label23.Text = "RELATIVE INFORMATION"
        '
        'exittBtn
        '
        Me.exittBtn.BackColor = System.Drawing.Color.LemonChiffon
        Me.exittBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.exittBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.exittBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.exittBtn.Location = New System.Drawing.Point(664, 575)
        Me.exittBtn.Name = "exittBtn"
        Me.exittBtn.Size = New System.Drawing.Size(112, 38)
        Me.exittBtn.TabIndex = 103
        Me.exittBtn.Text = "Exit"
        Me.exittBtn.UseVisualStyleBackColor = False
        '
        'UpdBtn
        '
        Me.UpdBtn.BackColor = System.Drawing.Color.LemonChiffon
        Me.UpdBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.UpdBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UpdBtn.Location = New System.Drawing.Point(440, 575)
        Me.UpdBtn.Name = "UpdBtn"
        Me.UpdBtn.Size = New System.Drawing.Size(106, 38)
        Me.UpdBtn.TabIndex = 104
        Me.UpdBtn.Text = "Update"
        Me.UpdBtn.UseVisualStyleBackColor = False
        '
        'PtnIDTxt
        '
        Me.PtnIDTxt.BackColor = System.Drawing.Color.SeaShell
        Me.PtnIDTxt.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.PtnIDTxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PtnIDTxt.Location = New System.Drawing.Point(100, 595)
        Me.PtnIDTxt.Name = "PtnIDTxt"
        Me.PtnIDTxt.Size = New System.Drawing.Size(70, 19)
        Me.PtnIDTxt.TabIndex = 107
        '
        'msgLbl
        '
        Me.msgLbl.AutoSize = True
        Me.msgLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.msgLbl.ForeColor = System.Drawing.Color.Red
        Me.msgLbl.Location = New System.Drawing.Point(446, 619)
        Me.msgLbl.Name = "msgLbl"
        Me.msgLbl.Size = New System.Drawing.Size(0, 15)
        Me.msgLbl.TabIndex = 108
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(12, 609)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(196, 20)
        Me.DateTimePicker1.TabIndex = 109
        '
        'PatientReg
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FloralWhite
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CancelButton = Me.exittBtn
        Me.ClientSize = New System.Drawing.Size(791, 641)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.msgLbl)
        Me.Controls.Add(Me.PtnIDTxt)
        Me.Controls.Add(Label26)
        Me.Controls.Add(Me.UpdBtn)
        Me.Controls.Add(Me.exittBtn)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.SaveBtn)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "PatientReg"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Patient Registration Form"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents BloodTxt As TextBox
    Friend WithEvents HeightTxt As TextBox
    Friend WithEvents WeightTxt As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Citytxt As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Agetxt As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Address1txt As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents Postcodetxt As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents IcNoTxt As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents phonePtnTxt As TextBox
    Friend WithEvents DOBtxt As TextBox
    Friend WithEvents PatientName As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents No As RadioButton
    Friend WithEvents Yes As RadioButton
    Friend WithEvents Label20 As Label
    Friend WithEvents InsTypetxt As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents EmpIDtxt As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents EmpAddTxt As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents CashRB As RadioButton
    Friend WithEvents InsRB As RadioButton
    Friend WithEvents Label17 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents SaveBtn As Button
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents Label25 As Label
    Friend WithEvents RelNameTxt As TextBox
    Friend WithEvents phoneRelTxt As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents exittBtn As Button
    Friend WithEvents UpdBtn As Button
    Friend WithEvents PtnIDTxt As TextBox
    Friend WithEvents MaleChkBox As CheckBox
    Friend WithEvents SngChkBox As CheckBox
    Friend WithEvents FemaleChkBox As CheckBox
    Friend WithEvents MrrChkBox As CheckBox
    Friend WithEvents Allergies As CheckBox
    Friend WithEvents Anemia As CheckBox
    Friend WithEvents Cancer As CheckBox
    Friend WithEvents BloodClot As CheckBox
    Friend WithEvents Adhd As CheckBox
    Friend WithEvents Anxiety As CheckBox
    Friend WithEvents Arthitis As CheckBox
    Friend WithEvents Asthma As CheckBox
    Friend WithEvents DiaType1 As CheckBox
    Friend WithEvents DiaType2 As CheckBox
    Friend WithEvents HiBP As CheckBox
    Friend WithEvents HiChole As CheckBox
    Friend WithEvents HeartAttc As CheckBox
    Friend WithEvents KidneyDis As CheckBox
    Friend WithEvents msgLbl As Label
    Friend WithEvents DateTimePicker1 As DateTimePicker
End Class
