﻿Imports System.Data.OleDb

Module Module1

    Public ConnSource As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\ClinicSystem1005\ClinicSystemsDatabase\Database_clinic.accdb"
    Public conn As New OleDbConnection(ConnSource)
    Public strsql As String

    Function connect()
        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If
        Return True
    End Function

End Module
