﻿Imports System.Configuration
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar

Public Class DailyPatientReg

    Dim count As Int16
    Dim newid As Int16
    Dim VisitTime As String = Now.ToString("d")

    Private Sub DailyPatientReg_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ptnIdtxt.Clear()
        nameTxt.Clear()
        empIdtxt.Clear()
        compTxt.Clear()
        insTxt.Clear()
        icTxt.Clear()
        msgLbl.Hide()

    End Sub

    Private Sub FindBtn_Click(sender As Object, e As EventArgs) Handles FindBtn.Click
        If ptnIdtxt.Text = Nothing Then
            MsgBox("Please input patient ID or employee id")
        End If
        strsql = "Select  NamePatient, PatientID, ICNo, EmpID, Employer, Insurance From   Patient_Information" &
                "    WHERE            (PatientID LIKE '%" & (ptnIdtxt.Text) & "%')" &
        " Or (EmpID Like '%" & ptnIdtxt.Text & "%')"

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        Dim cmd As New OleDbCommand(strsql, conn)
        Dim dr As OleDbDataReader = cmd.ExecuteReader()
        If dr.Read() Then
            nameTxt.Text = dr("NamePatient")
            empIdtxt.Text = dr("EmpID")
            compTxt.Text = dr("Employer")
            insTxt.Text = dr("Insurance")
            icTxt.Text = dr("ICNo")
        Else
            MsgBox("No data found! Please check again. If repeated 2times error, please check patient is registered or not.")
        End If
    End Sub

    Private Sub RegBtn_Click(sender As Object, e As EventArgs) Handles RegBtn.Click

        ptnName = nameTxt.Text
        ptnID = ptnIdtxt.Text
        status = "Waiting consultation"
        strsql = "SELECT COUNT(*) AS Expr1 FROM Waiting_List"
        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If
        Dim cmd As New OleDbCommand(strsql, conn)
        count = Convert.ToInt32(cmd.ExecuteScalar())
        If count = 0 Then
            newid = 1
            queueNo = newid
        Else
            newid = 1 + count
            queueNo = newid
        End If

        Try
            'Select Case ID, NamePatient, QueueNo, VisitingTime, ConsultationTime, Status From Waiting_List ptnIdtxt.Text
            strsql = "Insert into Waiting_List " &
            "(ID, NamePatient, QueueNo, VisitingTime, Status,PatientID)" &
            " Values " &
             "(@ID, @NamePatient, @QueueNo, @VisitingTime, @Status, @PatientID)"
            Dim cmd2 As New OleDbCommand(strsql, conn)
            cmd2.Parameters.AddWithValue("@ID", newid)
            cmd2.Parameters.AddWithValue("@NamePatient", ptnName)
            cmd2.Parameters.AddWithValue("@QueueNo", queueNo)
            cmd2.Parameters.AddWithValue("@VisitingTime", VisitTime)
            cmd2.Parameters.AddWithValue("@Status", status)
            cmd2.Parameters.AddWithValue("@PatientID", ptnID)
            cmd2.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show("There was an error processing your request. Please try again." & vbCrLf & vbCrLf &
                        "Original Error:" & vbCrLf & vbCrLf & ex.ToString, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        msgLbl.Text = "Finish registered"

    End Sub

    Private Sub ExitBtn_Click(sender As Object, e As EventArgs) Handles ExitBtn.Click
        Me.Close()
        NurseForm.Show()
    End Sub

End Class