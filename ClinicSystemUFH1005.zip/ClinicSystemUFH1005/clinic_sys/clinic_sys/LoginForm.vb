﻿Imports System.Data.OleDb
Imports System.Runtime.InteropServices

Public Class LoginForm

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = Nothing Or TextBox2.Text = Nothing Then
            MsgBox("Enter credentials!")
        Else
            If conn.State = ConnectionState.Closed Then
                conn.Open()
            End If
            strsql = "select count(*) from Login_table where userid=? and password=?"
            Dim cmd1 As New OleDbCommand(strsql, conn)
            cmd1.Parameters.AddWithValue("@1", OleDbType.VarChar).Value = TextBox1.Text
            cmd1.Parameters.AddWithValue("@2", OleDbType.VarChar).Value = TextBox2.Text
            Dim count = Convert.ToInt32(cmd1.ExecuteScalar())
            If count > 0 Then
                XX = TextBox1.Text
                Try
                    strsql = "UPDATE Login_table" & " SET Status = yes" & " WHERE (UserID ='" & XX & "')"
                    Dim cmd2 As New OleDbCommand(strsql, conn)
                    cmd2.ExecuteNonQuery()
                Catch ex As Exception
                    MessageBox.Show("There was an error processing your request. Please try again." & vbCrLf & vbCrLf &
                                    "Original Error:" & vbCrLf & vbCrLf & ex.ToString, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
                If YY = Nothing Then
                    MsgBox("Please choose your designation from admin/doctor/nurse before login", MsgBoxStyle.Information)
                Else
                    Me.Hide()
                    Select Case YY
                        Case "nurse"
                            NurseForm.Show()
                        Case "doctor"
                            DoctorForm.Show()
                        Case "admin"
                            NurseForm.Show()
                        Case Else
                            Me.Show()
                    End Select
                End If
            Else
                MsgBox("User ID or password is discorrect/not found!")
            End If
        End If
        conn.Close()

    End Sub
    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        YY = "nurse"
    End Sub
    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        YY = "doctor"
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        YY = "admin"
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
        Me.Close()
    End Sub

End Class
