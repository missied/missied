﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class NurseForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.RegBtn = New System.Windows.Forms.Button()
        Me.PayBtn = New System.Windows.Forms.Button()
        Me.NewBtn = New System.Windows.Forms.Button()
        Me.PatListBtn = New System.Windows.Forms.Button()
        Me.DrBtn = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.WaitTxt = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.IDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NamePatientDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.QueueNoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VisitingTimeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ConsultationTimeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.WaitingListBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        'Me.Database_clinicDataSet = New clinic_sys.Database_clinicDataSet()
        'Me.Waiting_ListTableAdapter = New clinic_sys.Database_clinicDataSetTableAdapters.Waiting_ListTableAdapter()
        Me.Visittxt = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.userIDtxt = New System.Windows.Forms.TextBox()
        Me.NurseName = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.JobTxt = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.EmpNoTxt = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.paytxt = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.ExittBtn = New System.Windows.Forms.Button()
        Me.DateTimePicker3 = New System.Windows.Forms.DateTimePicker()
        Me.MsgTxt = New System.Windows.Forms.TextBox()
        Me.RefreshBtn = New System.Windows.Forms.Button()
        Me.BtnMaintenance = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.WaitingListBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Database_clinicDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(6, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(0, 20)
        Me.Label1.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(6, 39)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(0, 20)
        Me.Label3.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(517, 28)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(0, 20)
        Me.Label4.TabIndex = 4
        '
        'RegBtn
        '
        Me.RegBtn.BackColor = System.Drawing.Color.Lavender
        Me.RegBtn.FlatAppearance.BorderColor = System.Drawing.Color.Silver
        Me.RegBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.RegBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RegBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RegBtn.Location = New System.Drawing.Point(12, 70)
        Me.RegBtn.Name = "RegBtn"
        Me.RegBtn.Size = New System.Drawing.Size(106, 34)
        Me.RegBtn.TabIndex = 7
        Me.RegBtn.Text = "Registration"
        Me.RegBtn.UseVisualStyleBackColor = False
        '
        'PayBtn
        '
        Me.PayBtn.BackColor = System.Drawing.Color.Lavender
        Me.PayBtn.FlatAppearance.BorderColor = System.Drawing.Color.Silver
        Me.PayBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.PayBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.PayBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PayBtn.Location = New System.Drawing.Point(12, 196)
        Me.PayBtn.Name = "PayBtn"
        Me.PayBtn.Size = New System.Drawing.Size(106, 28)
        Me.PayBtn.TabIndex = 8
        Me.PayBtn.Text = "Payment"
        Me.PayBtn.UseVisualStyleBackColor = False
        '
        'NewBtn
        '
        Me.NewBtn.BackColor = System.Drawing.Color.Lavender
        Me.NewBtn.FlatAppearance.BorderColor = System.Drawing.Color.Silver
        Me.NewBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.NewBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.NewBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NewBtn.Location = New System.Drawing.Point(12, 15)
        Me.NewBtn.Name = "NewBtn"
        Me.NewBtn.Size = New System.Drawing.Size(106, 49)
        Me.NewBtn.TabIndex = 9
        Me.NewBtn.Text = "New Patient Registration"
        Me.NewBtn.UseVisualStyleBackColor = False
        '
        'PatListBtn
        '
        Me.PatListBtn.BackColor = System.Drawing.Color.Lavender
        Me.PatListBtn.FlatAppearance.BorderColor = System.Drawing.Color.Silver
        Me.PatListBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.PatListBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.PatListBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PatListBtn.Location = New System.Drawing.Point(12, 110)
        Me.PatListBtn.Name = "PatListBtn"
        Me.PatListBtn.Size = New System.Drawing.Size(106, 25)
        Me.PatListBtn.TabIndex = 10
        Me.PatListBtn.Text = "Patient List"
        Me.PatListBtn.UseVisualStyleBackColor = False
        '
        'DrBtn
        '
        Me.DrBtn.BackColor = System.Drawing.Color.Lavender
        Me.DrBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.DrBtn.FlatAppearance.BorderColor = System.Drawing.Color.Silver
        Me.DrBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.DrBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.DrBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DrBtn.Location = New System.Drawing.Point(12, 139)
        Me.DrBtn.Name = "DrBtn"
        Me.DrBtn.Size = New System.Drawing.Size(106, 51)
        Me.DrBtn.TabIndex = 13
        Me.DrBtn.Text = "Doctor's On Duty"
        Me.DrBtn.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(148, 58)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(41, 20)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Wait"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(21, 58)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(39, 20)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "Visit"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(12, 40)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(221, 24)
        Me.TextBox2.TabIndex = 17
        Me.TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'WaitTxt
        '
        Me.WaitTxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.WaitTxt.Location = New System.Drawing.Point(195, 51)
        Me.WaitTxt.Name = "WaitTxt"
        Me.WaitTxt.Size = New System.Drawing.Size(55, 31)
        Me.WaitTxt.TabIndex = 20
        Me.WaitTxt.Text = "0"
        Me.WaitTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn, Me.NamePatientDataGridViewTextBoxColumn, Me.QueueNoDataGridViewTextBoxColumn, Me.VisitingTimeDataGridViewTextBoxColumn, Me.ConsultationTimeDataGridViewTextBoxColumn, Me.StatusDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.WaitingListBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(124, 196)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(647, 130)
        Me.DataGridView1.TabIndex = 22
        '
        'IDDataGridViewTextBoxColumn
        '
        Me.IDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        Me.IDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn.Name = "IDDataGridViewTextBoxColumn"
        '
        'NamePatientDataGridViewTextBoxColumn
        '
        Me.NamePatientDataGridViewTextBoxColumn.DataPropertyName = "NamePatient"
        Me.NamePatientDataGridViewTextBoxColumn.HeaderText = "NamePatient"
        Me.NamePatientDataGridViewTextBoxColumn.Name = "NamePatientDataGridViewTextBoxColumn"
        '
        'QueueNoDataGridViewTextBoxColumn
        '
        Me.QueueNoDataGridViewTextBoxColumn.DataPropertyName = "QueueNo"
        Me.QueueNoDataGridViewTextBoxColumn.HeaderText = "QueueNo"
        Me.QueueNoDataGridViewTextBoxColumn.Name = "QueueNoDataGridViewTextBoxColumn"
        '
        'VisitingTimeDataGridViewTextBoxColumn
        '
        Me.VisitingTimeDataGridViewTextBoxColumn.DataPropertyName = "VisitingTime"
        Me.VisitingTimeDataGridViewTextBoxColumn.HeaderText = "VisitingTime"
        Me.VisitingTimeDataGridViewTextBoxColumn.Name = "VisitingTimeDataGridViewTextBoxColumn"
        '
        'ConsultationTimeDataGridViewTextBoxColumn
        '
        Me.ConsultationTimeDataGridViewTextBoxColumn.DataPropertyName = "ConsultationTime"
        Me.ConsultationTimeDataGridViewTextBoxColumn.HeaderText = "ConsultationTime"
        Me.ConsultationTimeDataGridViewTextBoxColumn.Name = "ConsultationTimeDataGridViewTextBoxColumn"
        '
        'StatusDataGridViewTextBoxColumn
        '
        Me.StatusDataGridViewTextBoxColumn.DataPropertyName = "Status"
        Me.StatusDataGridViewTextBoxColumn.HeaderText = "Status"
        Me.StatusDataGridViewTextBoxColumn.Name = "StatusDataGridViewTextBoxColumn"
        '
        'WaitingListBindingSource
        '
        Me.WaitingListBindingSource.DataMember = "Waiting_List"
        Me.WaitingListBindingSource.DataSource = Me.Database_clinicDataSet
        '
        'Database_clinicDataSet
        '
        Me.Database_clinicDataSet.DataSetName = "Database_clinicDataSet"
        Me.Database_clinicDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Waiting_ListTableAdapter
        '
        Me.Waiting_ListTableAdapter.ClearBeforeFill = True
        '
        'Visittxt
        '
        Me.Visittxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Visittxt.Location = New System.Drawing.Point(66, 51)
        Me.Visittxt.Name = "Visittxt"
        Me.Visittxt.Size = New System.Drawing.Size(55, 31)
        Me.Visittxt.TabIndex = 24
        Me.Visittxt.Text = "0"
        Me.Visittxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.TextBox2)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(124, 5)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(249, 73)
        Me.GroupBox1.TabIndex = 25
        Me.GroupBox1.TabStop = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.Label10.Location = New System.Drawing.Point(50, 15)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(158, 18)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "DOCTOR'S ON DUTY"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.userIDtxt)
        Me.GroupBox2.Controls.Add(Me.NurseName)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.JobTxt)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.EmpNoTxt)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(124, 84)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(249, 106)
        Me.GroupBox2.TabIndex = 26
        Me.GroupBox2.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.Label2.Location = New System.Drawing.Point(60, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(137, 18)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "MY INFORMATION"
        '
        'userIDtxt
        '
        Me.userIDtxt.Location = New System.Drawing.Point(171, 71)
        Me.userIDtxt.Name = "userIDtxt"
        Me.userIDtxt.Size = New System.Drawing.Size(62, 24)
        Me.userIDtxt.TabIndex = 19
        Me.userIDtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NurseName
        '
        Me.NurseName.Location = New System.Drawing.Point(12, 38)
        Me.NurseName.Name = "NurseName"
        Me.NurseName.Size = New System.Drawing.Size(221, 24)
        Me.NurseName.TabIndex = 18
        Me.NurseName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(6, 13)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(0, 20)
        Me.Label6.TabIndex = 1
        '
        'JobTxt
        '
        Me.JobTxt.Location = New System.Drawing.Point(80, 71)
        Me.JobTxt.Name = "JobTxt"
        Me.JobTxt.Size = New System.Drawing.Size(85, 24)
        Me.JobTxt.TabIndex = 16
        Me.JobTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(6, 39)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(0, 20)
        Me.Label7.TabIndex = 3
        '
        'EmpNoTxt
        '
        Me.EmpNoTxt.Location = New System.Drawing.Point(12, 71)
        Me.EmpNoTxt.Name = "EmpNoTxt"
        Me.EmpNoTxt.Size = New System.Drawing.Size(62, 24)
        Me.EmpNoTxt.TabIndex = 17
        Me.EmpNoTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.paytxt)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.Label11)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.Visittxt)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.WaitTxt)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(379, 84)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(392, 106)
        Me.GroupBox3.TabIndex = 26
        Me.GroupBox3.TabStop = False
        '
        'paytxt
        '
        Me.paytxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.paytxt.Location = New System.Drawing.Point(319, 51)
        Me.paytxt.Name = "paytxt"
        Me.paytxt.Size = New System.Drawing.Size(55, 31)
        Me.paytxt.TabIndex = 26
        Me.paytxt.Text = "0"
        Me.paytxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(278, 58)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 20)
        Me.Label5.TabIndex = 25
        Me.Label5.Text = "Pay"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Blue
        Me.Label11.Location = New System.Drawing.Point(105, 15)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(193, 25)
        Me.Label11.TabIndex = 18
        Me.Label11.Text = "PATIENT COUNT"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(6, 13)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(0, 20)
        Me.Label12.TabIndex = 1
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(6, 39)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(0, 20)
        Me.Label13.TabIndex = 3
        '
        'ExittBtn
        '
        Me.ExittBtn.BackColor = System.Drawing.Color.Lavender
        Me.ExittBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.ExittBtn.FlatAppearance.BorderColor = System.Drawing.Color.Silver
        Me.ExittBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ExittBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ExittBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExittBtn.Location = New System.Drawing.Point(12, 301)
        Me.ExittBtn.Name = "ExittBtn"
        Me.ExittBtn.Size = New System.Drawing.Size(106, 25)
        Me.ExittBtn.TabIndex = 29
        Me.ExittBtn.Text = "Exit"
        Me.ExittBtn.UseVisualStyleBackColor = False
        '
        'DateTimePicker3
        '
        Me.DateTimePicker3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePicker3.Location = New System.Drawing.Point(379, 15)
        Me.DateTimePicker3.Name = "DateTimePicker3"
        Me.DateTimePicker3.Size = New System.Drawing.Size(392, 31)
        Me.DateTimePicker3.TabIndex = 28
        '
        'MsgTxt
        '
        Me.MsgTxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MsgTxt.Location = New System.Drawing.Point(379, 52)
        Me.MsgTxt.Name = "MsgTxt"
        Me.MsgTxt.Size = New System.Drawing.Size(392, 26)
        Me.MsgTxt.TabIndex = 30
        '
        'RefreshBtn
        '
        Me.RefreshBtn.BackColor = System.Drawing.Color.Lavender
        Me.RefreshBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.RefreshBtn.FlatAppearance.BorderColor = System.Drawing.Color.Silver
        Me.RefreshBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.RefreshBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RefreshBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RefreshBtn.Location = New System.Drawing.Point(12, 230)
        Me.RefreshBtn.Name = "RefreshBtn"
        Me.RefreshBtn.Size = New System.Drawing.Size(106, 27)
        Me.RefreshBtn.TabIndex = 31
        Me.RefreshBtn.Text = "Refresh"
        Me.RefreshBtn.UseVisualStyleBackColor = False
        '
        'BtnMaintenance
        '
        Me.BtnMaintenance.BackColor = System.Drawing.Color.Lavender
        Me.BtnMaintenance.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.BtnMaintenance.FlatAppearance.BorderColor = System.Drawing.Color.Silver
        Me.BtnMaintenance.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.BtnMaintenance.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnMaintenance.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnMaintenance.Location = New System.Drawing.Point(12, 263)
        Me.BtnMaintenance.Name = "BtnMaintenance"
        Me.BtnMaintenance.Size = New System.Drawing.Size(106, 32)
        Me.BtnMaintenance.TabIndex = 32
        Me.BtnMaintenance.Text = "Maintenance"
        Me.BtnMaintenance.UseVisualStyleBackColor = False
        Me.BtnMaintenance.Visible = False
        '
        'NurseForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.BackColor = System.Drawing.Color.FloralWhite
        Me.ClientSize = New System.Drawing.Size(788, 342)
        Me.Controls.Add(Me.BtnMaintenance)
        Me.Controls.Add(Me.RefreshBtn)
        Me.Controls.Add(Me.MsgTxt)
        Me.Controls.Add(Me.ExittBtn)
        Me.Controls.Add(Me.DateTimePicker3)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.DrBtn)
        Me.Controls.Add(Me.PatListBtn)
        Me.Controls.Add(Me.NewBtn)
        Me.Controls.Add(Me.PayBtn)
        Me.Controls.Add(Me.RegBtn)
        Me.Controls.Add(Me.Label4)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "NurseForm"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Visiting Information"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.WaitingListBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Database_clinicDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents RegBtn As Button
    Friend WithEvents PayBtn As Button
    Friend WithEvents NewBtn As Button
    Friend WithEvents PatListBtn As Button
    Friend WithEvents DrBtn As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents WaitTxt As TextBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Database_clinicDataSet As Database_clinicDataSet
    Friend WithEvents WaitingListBindingSource As BindingSource
    Friend WithEvents Waiting_ListTableAdapter As Database_clinicDataSetTableAdapters.Waiting_ListTableAdapter
    Friend WithEvents IDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NamePatientDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents QueueNoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents VisitingTimeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ConsultationTimeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StatusDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Visittxt As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents userIDtxt As TextBox
    Friend WithEvents NurseName As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents JobTxt As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents EmpNoTxt As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents paytxt As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents ExittBtn As Button
    Friend WithEvents MsgTxt As TextBox
    Friend WithEvents DateTimePicker3 As DateTimePicker
    Friend WithEvents RefreshBtn As Button
    Friend WithEvents BtnMaintenance As Button
End Class
