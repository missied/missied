﻿
Imports System.Data.Common
Imports System.Data.OleDb
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Public Class DrOnduty

    Dim da As New OleDbDataAdapter
    Dim dset As New DataSet
    Dim data As String
    Dim aa As String

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

        aa = ComboBox1.Text

    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        drDuty = aa
        NurseForm.TextBox2.Text = aa

        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If

        Me.Close()
        NurseForm.Show()

    End Sub

    Private Sub DrOnduty_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If

        strsql = "SELECT name from employee_information where designation= 'doctor'"
        Dim cmd As New OleDbCommand(strsql, conn)
        Dim dr As OleDbDataReader
        dr = cmd.ExecuteReader
        If dr.Read Then
            ComboBox1.Items.Add(dr("name").ToString())
        End If
        conn.Close()

        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If

    End Sub
End Class