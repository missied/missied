﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.Data.OracleClient
Imports System.Diagnostics.CodeAnalysis
Imports System.Diagnostics.Eventing.Reader
Imports System.DirectoryServices.ActiveDirectory
Imports System.IO
Imports System.Runtime.CompilerServices
Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Formatters
Imports System.Security.Policy
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports System.Xml
Imports Microsoft.VisualBasic.ApplicationServices

Public Class Mainform_book

    Private Sub Mainform_book_Load() Handles MyBase.Load

        MsgBox("Directory for this application: [C:\book tracker]." & vbCrLf & "Please copy the folder to right directory." & vbCrLf & "Or else, you can't update/track the progress.")
        Call Log_Info()
    End Sub

    Public Sub Log_Info()

        Dim latestbook As String
        Dim qty1 As Integer
        Dim now As DateTime = DateTime.Now
        Dim bookcount_log As String = "C:\book tracker\logging\bookcount.txt"

        TextBox2.Text = ""
        TextBox1.Text = ""

        Label2.Text = now.ToString("dd/MM/yy")

        If File.Exists(bookcount_log) Then
            latestbook = File.ReadLines(bookcount_log).Last
            qty1 = Conversion.Int(latestbook)
            If qty1 >= 1 And qty1 < 5 Then
                Label4.Text = "Keep it up!! Until today, you have read " & latestbook & " books."
            ElseIf qty1 >= 6 And qty1 >= 10 Then
                Label4.Text = "Good job!! Until today, you have read " & latestbook & " books."
            ElseIf qty1 >= 11 Then
                Label4.Text = "Awesome!! Until today, you have read " & latestbook & " books."
            End If
        Else
            Label4.Text = "Meh!! You haven't read any book (T_T)!"
        End If

        ComboBox1.Items.Add("January")
        ComboBox1.Items.Add("February")
        ComboBox1.Items.Add("March")
        ComboBox1.Items.Add("April")
        ComboBox1.Items.Add("May")
        ComboBox1.Items.Add("June")
        ComboBox1.Items.Add("July")
        ComboBox1.Items.Add("August")
        ComboBox1.Items.Add("September")
        ComboBox1.Items.Add("October")
        ComboBox1.Items.Add("November")
        ComboBox1.Items.Add("December")
        ComboBox1.Text = "Select from..."

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

        Dim objreader As System.IO.StreamReader
        Dim data As String
        Dim aa As String

        aa = ComboBox1.Text
        aa = aa & ".txt"

        Dim file_name As String = "C:\book tracker\logging\\" & aa

        If File.Exists(file_name) Then
            objreader = My.Computer.FileSystem.OpenTextFileReader(file_name)
            data = objreader.ReadToEnd
            objreader.Close()
            TextBox1.Text = data
            TextBox2.Text = File.ReadAllLines(file_name).Length
        Else
            TextBox1.Text = "You didn't read any book!"
            TextBox2.Text = 0
        End If

        'If ComboBox1.SelectedItem = "January" Then

        '    Dim file_name As String = "C:\book tracker\logging\\January.txt"

        '    If File.Exists(file_name) Then
        '        objreader = My.Computer.FileSystem.OpenTextFileReader(file_name)
        '        data = objreader.ReadToEnd
        '        objreader.Close()
        '        TextBox1.Text = data
        '        TextBox2.Text = File.ReadAllLines(file_name).Length
        '    Else
        '        TextBox1.Text = "You didn't read any book!"
        '        TextBox2.Text = 0
        '    End If

        'End If

        'If ComboBox1.SelectedItem = "February" Then

        '    Dim file_name As String = "C:\book tracker\logging\\February.txt"

        '    If File.Exists(file_name) Then
        '        objreader = My.Computer.FileSystem.OpenTextFileReader(file_name)
        '        data = objreader.ReadToEnd
        '        objreader.Close()
        '        TextBox1.Text = data
        '        TextBox2.Text = File.ReadAllLines(file_name).Length
        '    Else
        '        TextBox1.Text = "You didn't read any book!"
        '        TextBox2.Text = 0
        '    End If

        'End If

        'If ComboBox1.SelectedItem = "March" Then

        '    Dim file_name As String = "C:\book tracker\logging\\March.txt"

        '    If File.Exists(file_name) Then
        '        objreader = My.Computer.FileSystem.OpenTextFileReader(file_name)
        '        data = objreader.ReadToEnd
        '        objreader.Close()
        '        TextBox1.Text = data
        '        TextBox2.Text = File.ReadAllLines(file_name).Length
        '    Else
        '        TextBox1.Text = "You didn't read any book!"
        '        TextBox2.Text = 0
        '    End If
        'End If

        'If ComboBox1.SelectedItem = "April" Then

        '    Dim file_name As String = "C:\book tracker\logging\\April.txt"

        '    If File.Exists(file_name) Then
        '        objreader = My.Computer.FileSystem.OpenTextFileReader(file_name)
        '        data = objreader.ReadToEnd
        '        objreader.Close()
        '        TextBox1.Text = data
        '        TextBox2.Text = File.ReadAllLines(file_name).Length
        '    Else
        '        TextBox1.Text = "You didn't read any book!"
        '        TextBox2.Text = 0
        '    End If
        'End If

        'If ComboBox1.SelectedItem = "May" Then

        '    Dim file_name As String = "C:\book tracker\logging\\May.txt"

        '    If File.Exists(file_name) Then
        '        objreader = My.Computer.FileSystem.OpenTextFileReader(file_name)
        '        data = objreader.ReadToEnd
        '        objreader.Close()
        '        TextBox1.Text = data
        '        TextBox2.Text = File.ReadAllLines(file_name).Length
        '    Else
        '        TextBox1.Text = "You didn't read any book!"
        '        TextBox2.Text = 0
        '    End If

        'End If

        'If ComboBox1.SelectedItem = "June" Then

        '    Dim file_name As String = "C:\book tracker\logging\\June.txt"

        '    If File.Exists(file_name) Then
        '        objreader = My.Computer.FileSystem.OpenTextFileReader(file_name)
        '        data = objreader.ReadToEnd
        '        objreader.Close()
        '        TextBox1.Text = data
        '        TextBox2.Text = File.ReadAllLines(file_name).Length
        '    Else
        '        TextBox1.Text = "You didn't read any book!"
        '        TextBox2.Text = 0
        '    End If

        'End If

        'If ComboBox1.SelectedItem = "July" Then

        '    Dim file_name As String = "C:\book tracker\logging\\July.txt"

        '    If File.Exists(file_name) Then
        '        objreader = My.Computer.FileSystem.OpenTextFileReader(file_name)
        '        data = objreader.ReadToEnd
        '        objreader.Close()
        '        TextBox1.Text = data
        '        TextBox2.Text = File.ReadAllLines(file_name).Length
        '    Else
        '        TextBox1.Text = "You didn't read any book!"
        '        TextBox2.Text = 0
        '    End If

        'End If

        'If ComboBox1.SelectedItem = "August" Then

        '    Dim file_name As String = "C:\book tracker\logging\\August.txt"

        '    If File.Exists(file_name) Then
        '        objreader = My.Computer.FileSystem.OpenTextFileReader(file_name)
        '        data = objreader.ReadToEnd
        '        objreader.Close()
        '        TextBox1.Text = data
        '        TextBox2.Text = File.ReadAllLines(file_name).Length
        '    Else
        '        TextBox1.Text = "You didn't read any book!"
        '        TextBox2.Text = 0
        '    End If

        'End If

        'If ComboBox1.SelectedItem = "September" Then

        '    Dim file_name As String = "C:\book tracker\logging\\September.txt"

        '    If File.Exists(file_name) Then
        '        objreader = My.Computer.FileSystem.OpenTextFileReader(file_name)
        '        data = objreader.ReadToEnd
        '        objreader.Close()
        '        TextBox1.Text = data
        '        TextBox2.Text = File.ReadAllLines(file_name).Length
        '    Else
        '        TextBox1.Text = "You didn't read any book!"
        '        TextBox2.Text = 0
        '    End If

        'End If

        'If ComboBox1.SelectedItem = "October" Then

        '    Dim file_name As String = "C:\book tracker\logging\\October.txt"

        '    If File.Exists(file_name) Then
        '        objreader = My.Computer.FileSystem.OpenTextFileReader(file_name)
        '        data = objreader.ReadToEnd
        '        objreader.Close()
        '        TextBox1.Text = data
        '        TextBox2.Text = File.ReadAllLines(file_name).Length
        '    Else
        '        TextBox1.Text = "You didn't read any book!"
        '        TextBox2.Text = 0
        '    End If

        'End If

        'If ComboBox1.SelectedItem = "November" Then

        '    Dim file_name As String = "C:\book tracker\logging\\November.txt"

        '    If File.Exists(file_name) Then
        '        objreader = My.Computer.FileSystem.OpenTextFileReader(file_name)
        '        data = objreader.ReadToEnd
        '        objreader.Close()
        '        TextBox1.Text = data
        '        TextBox2.Text = File.ReadAllLines(file_name).Length
        '    Else
        '        TextBox1.Text = "You didn't read any book!"
        '        TextBox2.Text = 0
        '    End If

        'End If

        'If ComboBox1.SelectedItem = "December" Then

        '    Dim file_name As String = "C:\book tracker\logging\\December.txt"

        '    If File.Exists(file_name) Then
        '        objreader = My.Computer.FileSystem.OpenTextFileReader(file_name)
        '        data = objreader.ReadToEnd
        '        objreader.Close()
        '        TextBox1.Text = data
        '        TextBox2.Text = File.ReadAllLines(file_name).Length
        '    Else
        '        TextBox1.Text = "You didn't read any book!"
        '        TextBox2.Text = 0
        '    End If

        'End If

    End Sub

    Private Sub Btn_Upd_Click(sender As Object, e As EventArgs) Handles Btn_Upd.Click

        Book_Entry.Show()
        Me.Hide()

    End Sub

    Private Sub Button1_Click() Handles Button1.Click
        Call Log_Info()
    End Sub

End Class