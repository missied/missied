﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Mainform_book
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label4 = New Label()
        ComboBox1 = New ComboBox()
        GroupBox1 = New GroupBox()
        TextBox1 = New TextBox()
        TextBox2 = New TextBox()
        Label5 = New Label()
        Btn_Upd = New Button()
        GroupBox2 = New GroupBox()
        Label7 = New Label()
        Label2 = New Label()
        Button1 = New Button()
        GroupBox1.SuspendLayout()
        GroupBox2.SuspendLayout()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Bahnschrift", 16F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.ForeColor = Color.BlueViolet
        Label1.Location = New Point(11, 6)
        Label1.Margin = New Padding(2, 0, 2, 0)
        Label1.Name = "Label1"
        Label1.Size = New Size(238, 27)
        Label1.TabIndex = 0
        Label1.Text = "WELCOME  TO  B U K U"
        ' 
        ' Label4
        ' 
        Label4.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Label4.AutoSize = True
        Label4.Font = New Font("Bahnschrift", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label4.ForeColor = Color.IndianRed
        Label4.Location = New Point(21, 42)
        Label4.Margin = New Padding(2, 0, 2, 0)
        Label4.Name = "Label4"
        Label4.Size = New Size(118, 18)
        Label4.TabIndex = 4
        Label4.Text = "Message for you"
        Label4.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' ComboBox1
        ' 
        ComboBox1.BackColor = Color.White
        ComboBox1.Font = New Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point)
        ComboBox1.FormattingEnabled = True
        ComboBox1.Location = New Point(10, 24)
        ComboBox1.Margin = New Padding(2)
        ComboBox1.Name = "ComboBox1"
        ComboBox1.Size = New Size(134, 25)
        ComboBox1.TabIndex = 9
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(TextBox1)
        GroupBox1.Controls.Add(TextBox2)
        GroupBox1.Controls.Add(Label5)
        GroupBox1.Controls.Add(ComboBox1)
        GroupBox1.Font = New Font("Bahnschrift", 10F, FontStyle.Regular, GraphicsUnit.Point)
        GroupBox1.Location = New Point(11, 155)
        GroupBox1.Margin = New Padding(2)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Padding = New Padding(2)
        GroupBox1.Size = New Size(364, 242)
        GroupBox1.TabIndex = 10
        GroupBox1.TabStop = False
        GroupBox1.Text = "Monthly List"
        ' 
        ' TextBox1
        ' 
        TextBox1.BackColor = Color.White
        TextBox1.BorderStyle = BorderStyle.FixedSingle
        TextBox1.Font = New Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point)
        TextBox1.Location = New Point(10, 59)
        TextBox1.Multiline = True
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(349, 178)
        TextBox1.TabIndex = 12
        ' 
        ' TextBox2
        ' 
        TextBox2.BackColor = Color.MistyRose
        TextBox2.Font = New Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point)
        TextBox2.ForeColor = Color.Blue
        TextBox2.Location = New Point(293, 24)
        TextBox2.Margin = New Padding(2)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(54, 25)
        TextBox2.TabIndex = 11
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(224, 28)
        Label5.Margin = New Padding(2, 0, 2, 0)
        Label5.Name = "Label5"
        Label5.Size = New Size(65, 17)
        Label5.TabIndex = 10
        Label5.Text = "Quantity "
        ' 
        ' Btn_Upd
        ' 
        Btn_Upd.BackColor = Color.FromArgb(CByte(255), CByte(255), CByte(192))
        Btn_Upd.Location = New Point(238, 18)
        Btn_Upd.Margin = New Padding(2)
        Btn_Upd.Name = "Btn_Upd"
        Btn_Upd.Size = New Size(109, 31)
        Btn_Upd.TabIndex = 11
        Btn_Upd.Text = "Update"
        Btn_Upd.UseVisualStyleBackColor = False
        ' 
        ' GroupBox2
        ' 
        GroupBox2.Controls.Add(Label7)
        GroupBox2.Controls.Add(Btn_Upd)
        GroupBox2.Font = New Font("Bahnschrift", 10F, FontStyle.Regular, GraphicsUnit.Point)
        GroupBox2.Location = New Point(11, 83)
        GroupBox2.Margin = New Padding(2)
        GroupBox2.Name = "GroupBox2"
        GroupBox2.Padding = New Padding(2)
        GroupBox2.Size = New Size(364, 57)
        GroupBox2.TabIndex = 12
        GroupBox2.TabStop = False
        GroupBox2.Text = "Update progress"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(9, 25)
        Label7.Margin = New Padding(2, 0, 2, 0)
        Label7.Name = "Label7"
        Label7.Size = New Size(222, 17)
        Label7.TabIndex = 12
        Label7.Text = "Click [Update] for new book entry"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Bahnschrift", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.ForeColor = SystemColors.ControlDark
        Label2.Location = New Point(304, 11)
        Label2.Margin = New Padding(2, 0, 2, 0)
        Label2.Name = "Label2"
        Label2.Size = New Size(80, 19)
        Label2.TabIndex = 13
        Label2.Text = "00/ 00/00"
        Label2.TextAlign = ContentAlignment.MiddleRight
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("Bahnschrift", 9.75F, FontStyle.Regular, GraphicsUnit.Point)
        Button1.Location = New Point(291, 402)
        Button1.Name = "Button1"
        Button1.Size = New Size(83, 27)
        Button1.TabIndex = 14
        Button1.Text = "Refresh"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Mainform_book
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.GhostWhite
        ClientSize = New Size(386, 440)
        Controls.Add(Button1)
        Controls.Add(Label2)
        Controls.Add(GroupBox2)
        Controls.Add(GroupBox1)
        Controls.Add(Label4)
        Controls.Add(Label1)
        Margin = New Padding(2)
        Name = "Mainform_book"
        StartPosition = FormStartPosition.CenterScreen
        Text = "B U K U - a book tracker"
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        GroupBox2.ResumeLayout(False)
        GroupBox2.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Btn_Upd As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Button1 As Button
End Class
