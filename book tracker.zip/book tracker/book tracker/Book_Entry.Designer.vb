﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Book_Entry
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(Book_Entry))
        Label1 = New Label()
        PictureBox1 = New PictureBox()
        Label4 = New Label()
        Label3 = New Label()
        TextBox2 = New TextBox()
        TextBox3 = New TextBox()
        MonthCalendar1 = New MonthCalendar()
        Label7 = New Label()
        Button2 = New Button()
        Label8 = New Label()
        Button3 = New Button()
        PictureBox3 = New PictureBox()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Bahnschrift", 15.75F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.ForeColor = Color.Blue
        Label1.Location = New Point(8, 9)
        Label1.Name = "Label1"
        Label1.Size = New Size(284, 25)
        Label1.TabIndex = 0
        Label1.Text = "B U K U - ENTRY NEW BOOK"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        PictureBox1.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(49, 14)
        PictureBox1.Margin = New Padding(3, 4, 3, 4)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(66, 0)
        PictureBox1.TabIndex = 4
        PictureBox1.TabStop = False
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(7, 53)
        Label4.Name = "Label4"
        Label4.Size = New Size(56, 18)
        Label4.TabIndex = 7
        Label4.Text = "Book Title"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(9, 89)
        Label3.Name = "Label3"
        Label3.Size = New Size(42, 18)
        Label3.TabIndex = 8
        Label3.Text = "Author"
        ' 
        ' TextBox2
        ' 
        TextBox2.BackColor = Color.Honeydew
        TextBox2.Location = New Point(68, 51)
        TextBox2.Margin = New Padding(3, 4, 3, 4)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(227, 26)
        TextBox2.TabIndex = 11
        ' 
        ' TextBox3
        ' 
        TextBox3.BackColor = Color.Honeydew
        TextBox3.Location = New Point(68, 86)
        TextBox3.Margin = New Padding(3, 4, 3, 4)
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(227, 26)
        TextBox3.TabIndex = 12
        ' 
        ' MonthCalendar1
        ' 
        MonthCalendar1.Location = New Point(68, 125)
        MonthCalendar1.Margin = New Padding(8, 11, 8, 11)
        MonthCalendar1.Name = "MonthCalendar1"
        MonthCalendar1.TabIndex = 20
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(8, 125)
        Label7.Name = "Label7"
        Label7.Size = New Size(30, 18)
        Label7.TabIndex = 21
        Label7.Text = "Date"
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.LightGoldenrodYellow
        Button2.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Button2.Location = New Point(315, 246)
        Button2.Margin = New Padding(3, 4, 3, 4)
        Button2.Name = "Button2"
        Button2.Size = New Size(84, 42)
        Button2.TabIndex = 22
        Button2.Text = "SAVE"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Bahnschrift SemiLight SemiConde", 12F, FontStyle.Regular, GraphicsUnit.Point)
        Label8.ForeColor = Color.FromArgb(CByte(0), CByte(192), CByte(0))
        Label8.Location = New Point(256, 306)
        Label8.Name = "Label8"
        Label8.Size = New Size(238, 19)
        Label8.TabIndex = 24
        Label8.Text = ChrW(8220) & "Today a reader, tomorrow a leader." & ChrW(8221)
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        Button3.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Button3.Location = New Point(405, 245)
        Button3.Margin = New Padding(3, 4, 3, 4)
        Button3.Name = "Button3"
        Button3.Size = New Size(89, 42)
        Button3.TabIndex = 25
        Button3.Text = "EXIT"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), Image)
        PictureBox3.Location = New Point(315, 53)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(179, 181)
        PictureBox3.TabIndex = 26
        PictureBox3.TabStop = False
        ' 
        ' Book_Entry
        ' 
        AutoScaleDimensions = New SizeF(6F, 18F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(508, 334)
        Controls.Add(PictureBox3)
        Controls.Add(Button3)
        Controls.Add(Label8)
        Controls.Add(Button2)
        Controls.Add(Label7)
        Controls.Add(MonthCalendar1)
        Controls.Add(TextBox3)
        Controls.Add(TextBox2)
        Controls.Add(Label3)
        Controls.Add(Label4)
        Controls.Add(PictureBox1)
        Controls.Add(Label1)
        Font = New Font("Bahnschrift Condensed", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        Margin = New Padding(3, 4, 3, 4)
        Name = "Book_Entry"
        StartPosition = FormStartPosition.CenterScreen
        Text = "B U K U - a book tracker"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents MonthCalendar1 As MonthCalendar
    Friend WithEvents Label7 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents PictureBox3 As PictureBox
End Class
