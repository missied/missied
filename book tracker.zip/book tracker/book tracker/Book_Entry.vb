﻿Imports System.Diagnostics.Eventing.Reader
Imports System.IO
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Book_Entry

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Dim bookname As String = TextBox2.Text
        Dim author As String = TextBox3.Text
        Dim day_selection As String = MonthCalendar1.SelectionRange.Start.Date.ToString("ddMMyy")
        'Dim now As DateTime = DateTime.Now
        Dim Newmonth_file As String = MonthCalendar1.SelectionRange.Start.Date.ToString("MMMM") 'now.ToString("MMMM")

        Dim file_name As String = "C:\book tracker\logging\" & Newmonth_file & ".txt"


        If System.IO.File.Exists(file_name) = False Then
            System.IO.File.Create(file_name).Dispose()
        End If

        Dim count As Integer = File.ReadAllLines(file_name).Length
        Dim objWriter As New System.IO.StreamWriter(file_name, True)
        Dim new_entry As String = Nothing

        If count = 0 Then
            new_entry = "1 - " & bookname & " / Author: " & author & " / Date: " & day_selection
        Else
            new_entry = (count + 1) & " - " & bookname & " / Author: " & author & " / Date: " & day_selection
        End If

        objWriter.WriteLine(new_entry)
        objWriter.Close()

        Dim bookcount_log As String = "C:\book tracker\logging\bookcount.txt"
        'Dim objreader As System.IO.StreamReader
        Dim countall As Integer
        'Dim read_count As String

        If System.IO.File.Exists(bookcount_log) = False Then
            System.IO.File.Create(bookcount_log).Dispose()
        End If

        Dim count1 As Integer = File.ReadAllLines(bookcount_log).Count
        Dim objWriter2 As New System.IO.StreamWriter(bookcount_log, True)

        If count1 = 0 Then
            countall = 1
        Else
            countall = count1 + 1
        End If

        objWriter2.WriteLine(countall)
        objWriter2.Close()

        'Once completed msg box display
        MsgBox("Book successfully saved to database!")

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        Dim latestbook As String
        Dim bookcount_log As String = "C:\book tracker\logging\bookcount.txt"

        If File.Exists(bookcount_log) Then
            latestbook = File.ReadLines(bookcount_log).Last
            Mainform_book.Label4.Text = "Congratulation !! Until today, you have read " & latestbook & " books."
        End If

        Mainform_book.TextBox2.Text = ""
        Mainform_book.TextBox1.Text = ""
        Mainform_book.ComboBox1.Text = "Select from..."

        Mainform_book.Show()
        Me.Close()

    End Sub

End Class
